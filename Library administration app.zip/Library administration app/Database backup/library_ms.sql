-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:4306
-- Generation Time: Apr 04, 2022 at 07:51 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library_ms`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id_book` int(11) NOT NULL,
  `title` varchar(250) DEFAULT NULL,
  `author` varchar(250) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id_book`, `title`, `author`, `quantity`) VALUES
(24, 'When Breath Becomes Air', 'Paul Kalanithi ', 2),
(29, 'The Beautifull Cassandra 2', 'Jane Austen', 7),
(30, 'Thinking, Fast and Slow', 'Daniel Kahneman', 2),
(31, 'Jane Eyre', 'Charlotte Bronte', 3),
(32, 'To Kill a Mockingbird', 'Harper Lee', 1),
(34, 'A Little Life', 'Hanya Yanagihara', 2),
(35, 'The Picture of Dorian Gray', 'Oscar Wilde ', 2),
(36, 'It Ends With Us', 'Collen Hoover', 5),
(38, 'Matilda', 'Roald Dahl', 3),
(39, 'carte noua', 'Daniel Kahneman', 2);

-- --------------------------------------------------------

--
-- Table structure for table `issue_book`
--

CREATE TABLE `issue_book` (
  `issue_id` int(11) NOT NULL,
  `book_title` varchar(250) DEFAULT NULL,
  `student_registration_number` varchar(100) DEFAULT NULL,
  `issue_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `issue_book`
--

INSERT INTO `issue_book` (`issue_id`, `book_title`, `student_registration_number`, `issue_date`, `due_date`, `status`) VALUES
(4, 'The Picture of Dorian Gray', '1001', '2021-12-28', '2022-01-03', 'pending'),
(5, 'The Picture of Dorian Gray', '1000', '2021-12-29', '2022-01-05', 'returned'),
(6, 'The Picture of Dorian Gray', '1002', '2021-12-29', '2022-01-02', 'returned'),
(8, 'The Beautifull Cassandra', '1000', '2021-12-29', '2021-12-31', 'returned'),
(9, 'When Breath Becomes Air 2', '1002', '2021-12-13', '2022-01-13', 'pending'),
(10, 'A Little Life', '1005', '2022-01-03', '2022-01-08', 'pending'),
(11, 'A Little Life', '1006', '2022-01-11', '2022-01-27', 'pending'),
(12, 'Matilda', '1005', '2022-01-04', '2022-01-21', 'returned'),
(13, 'Matilda', '1002', '2022-01-13', '2022-01-20', 'returned');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id_student` int(11) NOT NULL,
  `registration_number` int(11) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `faculty` varchar(100) DEFAULT NULL,
  `specialization` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id_student`, `registration_number`, `name`, `faculty`, `specialization`) VALUES
(1, 1000, 'Popescu Ariana', 'Facultatea de biologie si geologie', 'fizica informatica'),
(2, 1001, 'Livadaru Amelia', 'Facultatea de litere', 'limba si literatura'),
(3, 1002, 'Tulea Ovidiu', 'Facultatea de medicina', 'medicina'),
(6, 1003, 'Costea Margareta', 'Facultatea de automatica, calculatoare si electronica', 'mecatronica'),
(7, 1004, 'Georgescu Cosmin', 'Facultatea de litere', 'limbi moderne aplicate'),
(8, 1005, 'Georgescu Liviu', 'Facultatea de biologie si geologie', 'biochimie'),
(11, 1006, 'Marinescu Diana', 'Facultatea de medicina dentara', 'tehnica dentara');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_username` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `contact` varchar(20) DEFAULT NULL,
  `status` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_username`, `username`, `password`, `email`, `contact`, `status`) VALUES
(32, 'ana', '1234', 'ana@yahoo.com', '0736524598', 'disconnected'),
(38, 'user', 'parola', 'user@yahoo.com', '0754812236', 'disconnected');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id_book`);

--
-- Indexes for table `issue_book`
--
ALTER TABLE `issue_book`
  ADD PRIMARY KEY (`issue_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id_student`),
  ADD UNIQUE KEY `registration_number` (`registration_number`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id_book` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `issue_book`
--
ALTER TABLE `issue_book`
  MODIFY `issue_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id_student` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_username` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
