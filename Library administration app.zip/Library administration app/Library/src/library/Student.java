/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;
import jframe.DBConnection;

/**
 *
 * @author ioana
 */
public class Student {

    String registration_number;
    String name;
    String faculty;
    String specialization;

    public Student(String registration_number, String name, String faculty, String specialization) {
        this.registration_number = registration_number;
        this.name = name;
        this.faculty = faculty;
        this.specialization = specialization;
    }

    public Student() {

    }

    //cate inregistrari exista in tabelul studenti
    public int sendDataToCards() {

        Statement st = null;
        ResultSet rs = null;

        try {
            Connection con = DBConnection.getConnection();
            st = con.createStatement();
            rs = st.executeQuery("select * from students");
            rs.last();
            return rs.getRow();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }

    //returneaza tabelul cu studentii
    public void insertIntoTabel(DefaultTableModel table) {

        try {
            Connection con = DBConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from students");

            while (rs.next()) {
                String registration_number = rs.getString("registration_number");
                String name = rs.getString("name");
                String faculty = rs.getString("faculty");
                String specialization = rs.getString("specialization");

                Object[] obj = {registration_number, name, faculty, specialization};
                table.addRow(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //cauta in tabel studentul cu nr de inregistrare x si actualizeaza obiectul student cu detaliile sale
    public boolean getDetails(String registration_no) {

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement pst = con.prepareStatement("select * from students where registration_number = ?");
            pst.setString(1, registration_no);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {

                registration_number = rs.getString("registration_number");
                name = rs.getString("name");
                faculty = rs.getString("faculty");
                specialization = rs.getString("specialization");
                return true;
            }

            return false;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public String getRegistartionNumber() {
        return registration_number;
    }

    public String getName() {
        return name;
    }

    public String getFaculty() {
        return faculty;
    }

    public String getSpecialization() {
        return specialization;
    }

    //adauga detalii despre student in tabelul students din baza de date
    public boolean addStudent() {
        try {
            Connection con = DBConnection.getConnection();
            String sql = "insert into students(registration_number, name, faculty, specialization) values(?,?,?,?)";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, registration_number);
            pst.setString(2, name);
            pst.setString(3, faculty);
            pst.setString(4, specialization);

            int rowCount = pst.executeUpdate();
            if (rowCount > 0) {
                return true;
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    //schimba detaliile despre un student
    public boolean updateStudent() {
        try {
            Connection con = DBConnection.getConnection();
            String sql = "update students set name = ?,faculty = ?,specialization = ? where registration_number = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, name);
            pst.setString(2, faculty);
            pst.setString(3, specialization);
            pst.setString(4, registration_number);

            int rowCount = pst.executeUpdate();
            if (rowCount > 0) {
                return true;
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    //cauta daca studentul are o carte imprumutata
    public boolean searchIssue() {
        try {
            Connection con = DBConnection.getConnection();
            String sql = "select * from issue_book where student_registration_number = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, registration_number);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                return true;
            }
            return false;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

    }

    //sterge un student
    public boolean deleteStudent() {
        if (searchIssue()) {
            return false;
        }

        try {
            Connection con = DBConnection.getConnection();
            String sql = "delete from students where registration_number = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, registration_number);

            int rowCount = pst.executeUpdate();
            if (rowCount > 0) {
                return true;
            }
            return false;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
