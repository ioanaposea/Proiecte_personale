/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;
import jframe.DBConnection;

/**
 *
 * @author ioana
 */
public class Book {

    String title;
    String author;
    int quantity;

    public Book(String title, String author, int quantity) {
        this.title = title;
        this.author = author;
        this.quantity = quantity;
    }

    public Book() {

    }

    //cate inregistrari exista in tabelul carti
    public int sendDataToCards() {

        Statement st = null;
        ResultSet rs = null;

        try {
            Connection con = DBConnection.getConnection();
            st = con.createStatement();
            rs = st.executeQuery("select * from books");
            rs.last();
            return rs.getRow();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }

    //returneaza tabelul cu cartile
    public void insertIntoTabel(DefaultTableModel table) {

        try {
            Connection con = DBConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from books");

            while (rs.next()) {
                String title = rs.getString("title");
                String author = rs.getString("author");
                int quantity = rs.getInt("quantity");

                Object[] obj = {title, author, quantity};
                table.addRow(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //cauta in tabel cartea cu titlul x si actualizeaza obiectul carte cu detaliile sale
    public boolean getDetails(String book_title) {

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement pst = con.prepareStatement("select * from books where title = ?");
            pst.setString(1, book_title);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                title = rs.getString("title");
                author = rs.getString("author");
                quantity = rs.getInt("quantity");
                return true;
            }
            return false;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public int getQuantity() {
        return quantity;
    }

    //cauta in tabelul carti o anumita carte dupa titlu si autor
    public boolean searchBook() {

        boolean exist = false;
        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement pst = con.prepareStatement("select * from books where title = ? and author = ?");
            pst.setString(1, title);
            pst.setString(2, author);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                exist = true;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return exist;
    }

    //adauga detalii despre carte in baza de date
    public boolean addBook() {
        if (searchBook()) {
            return false;
        }

        try {
            Connection con = DBConnection.getConnection();
            String sql = "insert into books(title, author, quantity) values(?,?,?)";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, title);
            pst.setString(2, author);
            pst.setInt(3, quantity);

            int rowCount = pst.executeUpdate();
            if (rowCount > 0) {
                return true;
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    //schimba detaliile despre o carte
    public boolean updateBook(String oldTitle, String oldAuthor, int oldQuantity) {
        try {
            Connection con = DBConnection.getConnection();
            String sql = "update books set title = ?,author = ?,quantity = ? where title = ? and author = ? and quantity = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, title);
            pst.setString(2, author);
            pst.setInt(3, quantity);
            pst.setString(4, oldTitle);
            pst.setString(5, oldAuthor);
            pst.setInt(6, oldQuantity);

            int rowCount = pst.executeUpdate();
            if (rowCount > 0) {
                return true;
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    //cauta daca cartea e imprumutata
    public boolean searchIsIssued() {
        try {
            Connection con = DBConnection.getConnection();
            String sql = "select * from issue_book where book_title = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, title);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                return true;
            }
            return false;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

    }

    //sterge o carte
    public boolean deleteBook() {
        if (searchIsIssued()) {
            return false;
        }

        try {
            Connection con = DBConnection.getConnection();
            String sql = "delete from books where title = ? and author = ? and quantity = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, title);
            pst.setString(2, author);
            pst.setInt(3, quantity);

            int rowCount = pst.executeUpdate();
            if (rowCount > 0) {
                return true;
            }
            return false;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

}
