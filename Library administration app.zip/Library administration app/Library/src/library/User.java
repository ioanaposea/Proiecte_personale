/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import jframe.DBConnection;

/**
 *
 * @author ioana
 */
public class User {

    String name;
    String pwd;
    String email;
    String contact;
    String status;

    public User(String name, String pwd, String email, String contact) {
        this.name = name;
        this.pwd = pwd;
        this.email = email;
        this.contact = contact;
        status = "disconnected";
    }

    public User(String name, String pwd) {
        this.name = name;
        this.pwd = pwd;
        status = "disconnected";
    }

    public User() {

    }

    public int Add() {
        return BDUtils.insertUser(this.name, this.pwd, this.email, this.contact);
    }

    //conectarea in aplicatie
    public boolean Connect() {
        if (BDUtils.loginToDB(this.name, this.pwd)) {
            status = "connected";
            try {
                Connection con = DBConnection.getConnection();
                String sql = "update users set status = ? where username = ? and password = ?";
                PreparedStatement pst = con.prepareStatement(sql);
                pst.setString(1, "connected");
                pst.setString(2, name);
                pst.setString(3, pwd);

                int rowCount = pst.executeUpdate();
                if (rowCount > 0) {
                    return true;
                }
                return false;
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }
        return false;
    }

    public String getUsername() {
        return name;
    }

    //cauta in tabel users care este conectat
    public boolean getDetails() {

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement pst = con.prepareStatement("select * from users where status = ?");
            pst.setString(1, "connected");
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {

                name = rs.getString("username");
                //status = rs.getString("connected");
                return true;
            };

            return false;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    //deconectare din aplicatie
    public void disconnectUser() {
        try {
            Connection con = DBConnection.getConnection();
            String sql = "update users set status = ? where status = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, "disconnected");
            pst.setString(2, "connected");

            int rowCount = pst.executeUpdate();
            if (rowCount > 0) {
                return;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
