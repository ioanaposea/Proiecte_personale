/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library;

import jframe.DBConnection;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ioana
 */
public class Issue {

    String title;
    String registration_number;
    java.sql.Date IssueDate;
    java.sql.Date DueDate;
    String status;

    public Issue(String title, String registration_number, java.sql.Date IssueDate, java.sql.Date DueDate) {
        this.title = title;
        this.registration_number = registration_number;
        this.IssueDate = IssueDate;
        this.DueDate = DueDate;
        status = "pending";
    }

    public Issue(String title, String registration_number) {
        this.title = title;
        this.registration_number = registration_number;
        status = "pending";
    }

    public Issue() {

    }

    //cate inregistrari exista in tabelul imprumuturilor
    public int sendDataToCards() {

        Statement st = null;
        ResultSet rs = null;

        try {
            Connection con = DBConnection.getConnection();
            st = con.createStatement();
            String sql = "select * from issue_book where status = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, "pending");
            rs = pst.executeQuery();
            rs.last();
            return rs.getRow();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }

    //cati intarziati exista in tabelul imprumuturilor
    public int sendDefaultersDataToCards() {

        Statement st = null;
        ResultSet rs = null;

        long l = System.currentTimeMillis();
        Date todaysDate = new Date(l);

        try {
            Connection con = DBConnection.getConnection();
            String sql = "select * from issue_book where due_date < ? and status = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setDate(1, todaysDate);
            pst.setString(2, "pending");
            rs = pst.executeQuery();
            rs.last();
            return rs.getRow();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }

    public String getTitle() {
        return title;
    }

    public String getRegistrationNo() {
        return registration_number;
    }

    public java.sql.Date getIssueDate() {
        return IssueDate;
    }

    public java.sql.Date getDueDate() {
        return DueDate;
    }

    //insereaza imprumutul in baza de date
    public boolean insertIntoIssueBook() {

        try {
            Connection con = DBConnection.getConnection();
            String sql = "insert into issue_book (book_title,student_registration_number,issue_date,due_date,status) values(?,?,?,?,?)";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, title);
            pst.setString(2, registration_number);
            pst.setDate(3, IssueDate);
            pst.setDate(4, DueDate);
            status = "pending";
            pst.setString(5, status);

            int rowCount = pst.executeUpdate();
            if (rowCount > 0) {
                return true;
            }

            return false;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    //actualizeaza numarul de carti din biblioteca
    public boolean updateBookCount(int action) {
        try {
            Connection con = DBConnection.getConnection();
            String sql = null;
            if (action == -1) {
                sql = "update books set quantity = quantity - 1 where title = ?";
            }

            if (action == +1) {
                sql = "update books set quantity = quantity + 1 where title = ?";
            }
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, title);

            int rowCount = pst.executeUpdate();

            if (rowCount > 0) {
                return true;
            }
            return false;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    //verifica daca cartea respectiva este deja imprumutata de student sau nu
    public boolean isAlreadyIssued() {
        try {
            Connection con = DBConnection.getConnection();
            String sql = "select * from issue_book where book_title = ? and student_registration_number = ? and status = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, title);
            pst.setString(2, registration_number);
            pst.setString(3, "pending");

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                return true;
            }
            return false;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean getDetails() {
        try {
            Connection con = DBConnection.getConnection();
            String sql = "select * from issue_book where book_title = ? and student_registration_number = ? and status = ?";

            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, title);
            pst.setString(2, registration_number);
            pst.setString(3, "pending");

            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                IssueDate = rs.getDate("issue_date");
                DueDate = rs.getDate("due_date");
                return true;
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    //returnare carte de catre student
    public boolean returnBook() {
        try {
            Connection con = DBConnection.getConnection();
            String sql = "update issue_book set status = ? where student_registration_number = ? and book_title = ? and status = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            status = "returned";
            pst.setString(1, status);
            pst.setString(2, registration_number);
            pst.setString(3, title);
            pst.setString(4, "pending");

            int rowCount = pst.executeUpdate();
            if (rowCount > 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    //returneaza tabelul cu imprumuturile
    //bool mode =  true ---> cartile imprumutate in prezent si = false ---> toate imprumuturile existente
    public void insertIntoTable(DefaultTableModel table, boolean mode) {
        try {
            Connection con = DBConnection.getConnection();
            Statement st = con.createStatement();
            PreparedStatement pst;

            if (mode) {
                pst = con.prepareStatement("select * from issue_book where status = ?");
                pst.setString(1, "pending");
            } else {
                pst = con.prepareStatement("select * from issue_book");
            }

            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                String title = rs.getString("book_title");
                String registration_number = rs.getString("student_registration_number");
                java.sql.Date Issue = rs.getDate("issue_date");
                java.sql.Date Due = rs.getDate("due_date");
                String stat = rs.getString("status");

                Object[] obj = {title, registration_number, Issue, Due, stat};
                table.addRow(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //tabelul cu imprumuturi expirate
    public void insertIntoDefaulterTable(DefaultTableModel table) {
        long l = System.currentTimeMillis();
        Date todaysDate = new Date(l);

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement pst = con.prepareStatement("select * from issue_book where due_date < ? and status = ? ");
            pst.setDate(1, todaysDate);
            pst.setString(2, "pending");
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                String title = rs.getString("book_title");
                String registration_number = rs.getString("student_registration_number");
                java.sql.Date Issue = rs.getDate("issue_date");
                java.sql.Date Due = rs.getDate("due_date");
                String stat = rs.getString("status");

                Object[] obj = {title, registration_number, Issue, Due, stat};
                table.addRow(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    //cauta un imprumuturi intre data x si data y
    public boolean searchIssue(java.sql.Date fromDate, java.sql.Date toDate, DefaultTableModel table) {
        try {
            Connection con = DBConnection.getConnection();
            String sql = "select * from issue_book where issue_date BETWEEN ? and ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setDate(1, fromDate);
            pst.setDate(2, toDate);

            ResultSet rs = pst.executeQuery();

            if (rs.next() == false) {
                return false;
            }

            do {
                String bookName = rs.getString("book_title");
                String StudentNumber = rs.getString("student_registration_number");
                String issueDate = rs.getString("issue_date");
                String dueDate = rs.getString("due_date");
                String stat = rs.getString("status");

                Object[] obj = {bookName, StudentNumber, issueDate, dueDate, stat};
                table.addRow(obj);
            } while (rs.next());

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

        return true;
    }

    //schimba data de returnare a unei carti
    public boolean updateDueDate(java.sql.Date newDueDate) {
        try {
            Connection con = DBConnection.getConnection();
            String sql = "update issue_book set due_date = ? where student_registration_number = ? and book_title = ? and issue_date = ? and due_date = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setDate(1, newDueDate);
            pst.setString(2, registration_number);
            pst.setString(3, title);
            pst.setDate(4, IssueDate);
            pst.setDate(5, DueDate);

            DueDate = newDueDate;

            int rowCount = pst.executeUpdate();
            if (rowCount > 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
