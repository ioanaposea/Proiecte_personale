/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library;


import java.sql.Connection;
import java.sql.PreparedStatement;
import jframe.DBConnection;
import java.sql.ResultSet;

/**
 *
 * @author ioana
 */
public class BDUtils {

    //inserare user in tabelul users
    public static int insertUser(String name, String pwd, String email, String contact) {
        int updateRowCount = 0;
        try {
            Connection con = DBConnection.getConnection();
            String sql = "insert into users(username,password,email,contact, status) values(?,?,?,?,?)";
            PreparedStatement pst = con.prepareStatement(sql);

            pst.setString(1, name);
            pst.setString(2, pwd);
            pst.setString(3, email);
            pst.setString(4, contact);
            pst.setString(5, "disconnected");

            updateRowCount = pst.executeUpdate();

            return updateRowCount;

        } catch (Exception e) {
            e.printStackTrace();
            return updateRowCount;
        }
    }

    //verificare daca mai exista acest username in tabelul users
    public static boolean checkUniqueUsername(String name) {

        boolean exist = false;
        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement pst = con.prepareStatement("select * from users where username = ?");
            pst.setString(1, name);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                exist = true;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return exist;
    }

    //cautare daca exista numele de utilizator si parola in baza de date
    public static boolean loginToDB(String name, String pwd) {
        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement pst = con.prepareStatement("select * from users where username = ? and password = ?");

            pst.setString(1, name);
            pst.setString(2, pwd);

            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                return true;
            }
            return false;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

}
