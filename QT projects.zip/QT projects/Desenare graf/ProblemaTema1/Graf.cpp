#include "Graf.h"

std::vector<Arc> Graf::GetArce()
{
    return arce;
}

std::vector<Node> Graf::GetNoduri()
{
    return noduri;
}

void Graf::AddNod(Node n)
{
    n.setNumber(noduri.size());//a dat numarul nodului
    noduri.push_back(n);
}

void Graf::AddArc(Arc n)
{
    //CERINTA 2
    for(int i=0;i<arce.size();i++)
        if(arce[i].getFirstPoint().getNumber()==n.getFirstPoint().getNumber() && arce[i].getSecondPoint().getNumber()==n.getSecondPoint().getNumber())
            return;
    //SFARSIT CERINTA 2
    arce.push_back(n);
}

Node Graf::GetLastNode()
{
    return noduri[noduri.size()-1];
}

int Graf::getNumberofNodes()
{
    return noduri.size();
}

