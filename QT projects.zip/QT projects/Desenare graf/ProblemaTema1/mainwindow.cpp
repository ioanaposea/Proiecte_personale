#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "Node.h"
#include <QMouseEvent>
#include <QPainter>
#include <QFile>
#include<QTextStream>
#include <QRadioButton>
#include<QMessageBox>
#include<QPainter>
#include<QtMath>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    drawNode = false;
    drawArc = false;
    isOriented = false;
    ui->setupUi(this);
}

void MainWindow::mouseReleaseEvent(QMouseEvent *e)//cand se apasa pe butoanele mouse-ului
{
    drawNode = false;//pleaca initial pe "NULL", cum ar fi
    drawArc = false;//idem precedentul
    if(e->button() == Qt::RightButton)//click dreapta pe mouse
    {
        Node n(e->pos());//primeste pozitia unde se afla mouse-ul acum si in nod se incarca coordonatele
        //CERINTA 1 - SA NU SE SUPRAPUNA NODURILE
        QPointF p = e->localPos();
        std::vector<Node> noduri = g.GetNoduri();
        for(auto& index:noduri)
        {
            if(fabs(index.getPoint().x() - p.x()) < 20 && fabs(index.getPoint().y() - p.y()) < 20)
            {
                return;
            }
        }
        //AICI SE TERMINA CERINTA 1, iar daca este gasit un nod care sa existe deja la adresa la care se afla mouse-ul acum
        //atunci se va termina functia si nu se va pune alt nod, ca sa nu se suprapuna

        g.AddNod(n);//g este un graf si in acest moment se adauga un nod in el, adica locul unde se afla mouse-ul
        drawNode = true;//asta se face asa ca sa poata stii sa deseneze nodul in functia urmatoare - paintEvent
        update();
        firstNode = Node();
    }
    else//altfel, este clar ca-i click stanga pe mouse
    {
        QPointF p = e->localPos();
        std::vector<Node> noduri = g.GetNoduri();//se pun aici nodurile deja existente
        Node foundNode;
        for (auto& n : noduri)
        {
            if (fabs(n.getPoint().x() - p.x()) < 20 && fabs(n.getPoint().y() - p.y()) < 20)
            {
                foundNode = n;
                break;
            }
        }
        if (foundNode.getNumber() == -1)
            return;
        if (firstNode.getNumber() == -1)//inseamna ca abia am gasit primul nod al arcului
        {
            firstNode = foundNode;
        }
        else//am gasit al doilea nod al arcului, fiindca primul era deja gasit
        {
            secondNode = foundNode;
            g.AddArc(Arc(firstNode, secondNode));
            firstNode = Node();
            secondNode = Node();
            drawArc = true;
            update();
        }
    }

    //PT CERINTA 3
    QString filename = "MatriceDeAdiacenta.txt";
    QFile file(filename);
    file.open(QIODevice::WriteOnly);
    for(int i=0;i<g.getNumberofNodes();i++)//se scrie primul rand unde sunt puse nodurile
    {
        QTextStream out(&file);
            out <<i << " ";
    }
    file.close();

    file.open(QIODevice::Append);
    for(int i=0;i<g.getNumberofNodes();i++)//se pun randurile cu zerouri si 1-uri
    {
        QTextStream out(&file);
        out<<"\n";
        std::vector<Arc> arcele=g.GetArce();
        for(int j=0;j<g.getNumberofNodes();j++)
        {
             int ok=0;
             if(isOriented==false)
             {
                for(int k=0;k<arcele.size() && ok==0 ;k++)
                 {
                     if(arcele[k].getFirstPoint().getNumber()==i && arcele[k].getSecondPoint().getNumber()==j)
                         ok=1;
                    if(arcele[k].getFirstPoint().getNumber()==j && arcele[k].getSecondPoint().getNumber()==i)
                        ok=1;
                 }
             }
             else if(isOriented==true)
             {
                 for(int k=0;k<arcele.size() && ok==0 ;k++)
                 {
                     if(arcele[k].getFirstPoint().getNumber()==i && arcele[k].getSecondPoint().getNumber()==j)
                         ok=1;
                 }
             }
            if(ok==0)
                out <<"0 ";
            else if(ok==1)
                out<<"1 ";
        }
      }
    file.close();
    //sf cerinta 3


}

//CERINTA 5
void DrawLineWithArrow(QPainter& painter, QPoint start, QPoint end) {

  painter.setRenderHint(QPainter::Antialiasing, true);

  qreal arrowSize = 15; // size of head
  painter.setPen(Qt::black);
  painter.setBrush(Qt::black);

  QLineF line(end, start);

  double angle = std::atan2(-line.dy(), line.dx());
  QPointF arrowP1 = line.p1() + QPointF(sin(angle + M_PI / 3) * arrowSize,
                                        cos(angle + M_PI / 3) * arrowSize);
  QPointF arrowP2 = line.p1() + QPointF(sin(angle + M_PI - M_PI / 3) * arrowSize,
                                        cos(angle + M_PI - M_PI / 3) * arrowSize);

  QPolygonF arrowHead;
  arrowHead.clear();
  arrowHead << line.p1() << arrowP1 << arrowP2;
  painter.drawLine(line);
  painter.drawPolygon(arrowHead);

}
//SF CERINTA 5

void MainWindow::paintEvent(QPaintEvent *event)
{
    if (g.getNumberofNodes())//returneaza cate noduri sunt salvate in vectorul graf, gen daca sunt noduri, ca sa poata executa
    {
        QPainter p(this);
        std::vector<Node> noduri = g.GetNoduri();//primeste nodurile din vectorul noduri al GRAFULUI
        for(auto& nod: noduri)//cred ca deseneaza toate nodurile care sunt deja
        {
            QRect r(nod.getPoint().x()-10,nod.getPoint().y()-10, 20,20);//este vorba de un patrat
            //coord lui x, coord lui y, latime, inaltime
            p.drawEllipse(r);//Desenează elipsa definită de inceputul dreptunghiului la (x, y) cu lățimea și înălțimea date.
            //aici se deseneaza o elipsa, adica un cerc (care face parte din patrat - este in el)
            p.drawText(nod.getPoint(), QString::number(nod.getNumber()));//scrie textul - la noi este un simbol - langa elipsa desenata mai sus
        }
        std::vector<Arc> arce = g.GetArce();
        for(auto& arc: arce)//cred ca deseneaza toate arcele care sunt deja
        {
            //also CERINTA 5
            if(isOriented==false)
            {
               p.drawLine(arc.getFirstPoint().getPoint(), arc.getSecondPoint().getPoint());//deseneaza arcul fara sageata
            }
            else if(isOriented==true)
            {
                DrawLineWithArrow(p,arc.getFirstPoint().getPoint(), arc.getSecondPoint().getPoint());//deseneaza arcul CU sageata
            }
            //also sf CERINTA 5
        }
        //urmatoarele se executa doar daca am adaugat un nod sau un arc
        if (drawNode)//daca in mouseReleaseEvent am dat click dreapta, atunci drawNode s-a facut true si deci se executa
        {
            Node n = g.GetLastNode();
            p.setPen(QPen(Qt::red));//il tine pe ultimul nod pus la culoarea rosie
            QRect r(n.getPoint().x()-10,n.getPoint().y()-10, 20,20);
            p.drawEllipse(r);
            p.drawText(n.getPoint(), QString::number(n.getNumber()));
        }
        else if (drawArc)// la fel ca si if-ul anterior, numai ca se refera la desenatul arcului
        {
            //CERINTA 5
            if(isOriented==false)
            {
                p.setPen(QPen(Qt::red));
                p.drawLine(QLine(arce[arce.size()-1].getFirstPoint().getPoint(), arce[arce.size()-1].getSecondPoint().getPoint()));
            }
            else if(isOriented==true)
            {
                DrawLineWithArrow(p,arce[arce.size()-1].getFirstPoint().getPoint(), arce[arce.size()-1].getSecondPoint().getPoint());
            }
            //SF CERINTA 5
        }
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_SaveGraf_released()
{

}


void MainWindow::on_Orientat_clicked()
{
    isOriented = true;
}


void MainWindow::on_Neorientat_clicked()
{
    isOriented = false;
}


void MainWindow::on_pushButton_clicked()
{
    //CERINTA 4
    if(ui->radioButton->isChecked())
    {
        QMessageBox::information(this,"Optiune","ORIENTAT");
        on_Orientat_clicked();
    }
    if(ui->radioButton_2->isChecked())
    {
        QMessageBox::information(this,"Optiune","NEORIENTAT");
        on_Neorientat_clicked();
    }
    //sf CERINTA 4
}

