#include "Graf.h"

std::vector<Arc> Graf::GetArce()
{
    return arce;
}

std::vector<Node> Graf::GetNoduri()
{
    return noduri;
}

void Graf::AddNod(Node n)
{
    n.setNumber(noduri.size());//a dat numarul nodului
    noduri.push_back(n);
}

void Graf::AddArc(Arc n)
{
    //nu se permite duplicarea
    for(int i=0;i<arce.size();i++)
        if(arce[i].getFirstPoint().getNumber()==n.getFirstPoint().getNumber() && arce[i].getSecondPoint().getNumber()==n.getSecondPoint().getNumber())
            return;
    arce.push_back(n);
}

Node Graf::GetLastNode()
{
    return noduri[noduri.size()-1];
}

int Graf::getNumberofNodes()
{
    return noduri.size();
}

int Graf::getWantedNrNodes()
{
    return nrNodes;
}

void Graf::setWantedNrNodes(int aux)
{
    nrNodes=aux;
}

int Graf::getWantedPaths()
{
    return nrPaths;
}

void Graf::setWantedPaths(int aux)
{
    nrPaths=aux;
}

int Graf::getWantedCycles()
{
    return nrCycles;
}

void Graf::setWantedCycles(int aux)
{
    nrCycles=aux;
}

void Graf::clearArce()
{
    arce.clear();
}

void Graf::clearNoduri()
{
    noduri.clear();
}

void Graf::clearMatrix()
{
    for(int i=0;i<matrix.size();i++)
    {
        matrix[i].clear();
    }
    matrix.clear();
}

std::vector<std::vector<int>> Graf::GetMatrix()
{
    return matrix;
}

int random_number(const int& a, const int& b)
{
    std::random_device rd;
    std::mt19937 mt(rd());
    std::uniform_int_distribution<int> dist(a, b);

    return dist(mt);
}

void Graf::Paths()
{
    std::vector<bool> pathnode;
    for (int ind1 = 0; ind1 < nrNodes; ind1++)
    {
        std::vector <int> row;
        for (int ind2 = 0; ind2 < nrNodes; ind2++)
        {
            row.push_back(0);
        }
        matrix.push_back(row);
    }
    pathnode.resize(nrNodes);
    int s = 0;
    int t = nrNodes - 1;
    int k, l, v;
    for (int index = 1; index <= t; index++)
    {
        pathnode[index] = false;
    }
    pathnode[s] = true;
    int u = s;
    for (int j = 1; j < nrNodes ; j++)
    {
        k = random_number(0, nrNodes-j-1 );
        l = 0;
        for (v = 0; v < nrNodes; v++)
        {
            if (pathnode[v])
                continue;
            if (l == k)
                break;
            l++;
        }
        matrix[u][v] = 1;
        pathnode[v] = true;
        if (v == t)
            break;
        u = v;
    }

    //pun elementele din matrice in arce
    for(int i=0;i<nrNodes;i++)
    {
        for(int j=0;j<nrNodes;j++)
        {
            if(matrix[i][j]==1)
            {
                Node a,b;
                for(int k=0;k<noduri.size();k++)
                {
                    if(noduri[k].getNumber()==i)
                        a=noduri[k];
                    if(noduri[k].getNumber()==j)
                        b=noduri[k];
                }
                Arc aux(a,b);
                AddArc(aux);
            }
         }
      }
}

void Graf::Cycles()
{
    std::vector<bool> cyclenode;
    for(int ind1=0; ind1<nrNodes; ind1++)
    {
        std::vector <int> row;
        for(int ind2=0; ind2<nrNodes; ind2++)
        {
            row.push_back( 0 );
        }
        matrix.push_back(row);
     }
    cyclenode.resize(nrNodes);
    int uo,u,k,l,v;
    uo = random_number(0,nrNodes-1);
    for(int j=0;j<nrNodes;j++)
    {
        cyclenode[j]=false;
    }
    cyclenode[uo]=true;
    u=uo;
    for(int j=0;j<nrNodes-1;j++)
    {
        k = random_number(0, nrNodes-j-1);
        l = 0;
        for (v = 0; v < nrNodes-1; v++)
        {
            if (cyclenode[v])
                continue;
            if (l == k)
                break;
            l++;
        }
        if (u == v)
            j=j-1;
        else
        {
            matrix[u][v]=1;
            cyclenode[v]=true;
        }
        if(v==uo)
            break;
        u=v;
    }
    matrix[u][uo]=1;

    //pun elementele din matrice in arce
    for(int i=0;i<nrNodes;i++)
    {
        for(int j=0;j<nrNodes;j++)
        {
            if(matrix[i][j]==1)
            {
                Node a,b;
                for(int k=0;k<noduri.size();k++)
                {
                    if(noduri[k].getNumber()==i)
                        a=noduri[k];
                    if(noduri[k].getNumber()==j)
                        b=noduri[k];
                }
                Arc aux(a,b);
                AddArc(aux);
            }
        }
    }
}
