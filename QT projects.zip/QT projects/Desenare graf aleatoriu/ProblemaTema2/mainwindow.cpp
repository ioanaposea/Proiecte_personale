#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "Node.h"
#include <QMouseEvent>
#include <QPainter>
#include <QFile>
#include<QTextStream>
#include <QRadioButton>
#include<QMessageBox>
#include<QPainter>
#include<QtMath>
#include<random>
#include<vector>
#include<iostream>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    drawNode = false;
    drawArc = false;
    ui->setupUi(this);
}

void MainWindow::on_pushButton_3_clicked()
{
    int nodes;
    nodes=g.getWantedNrNodes();
    drawArc = false;
    drawNode = false;
    for(int i=0;i<nodes;i++)
    {
         int ok=1;
         QPoint p (rand()%400+100,rand()%400+100);
         Node n(p);
         std::vector<Node> noduri = g.GetNoduri();
         for(auto& index:noduri)
         {
             if(fabs(index.getPoint().x() - p.x()) < 20 && fabs(index.getPoint().y() - p.y()) < 20)
             {
                 ok=0;
             }
         }
         if(ok==1)
         {
            g.AddNod(n);
            drawNode = true;
         }
         else
             i--;
         update();
    }

    if(yesPath==true)
    {
        drawArc=true;
        g.Paths();
    }
    else if(yesCycle==true)
    {
        drawArc=true;
        g.Cycles();
    }
    if(yesCycle==true ||yesPath==true)
    {
        std::vector<std::vector<int>> Matrix;
        std::vector<std::vector<int>> listaAdiacenta;
        Matrix=g.GetMatrix();
        for (int i = 0; i < g.getWantedNrNodes(); i++)
        {
                std::vector<int> v1;

                for (int j = 0; j <g.getWantedNrNodes(); j++)
                {
                    if(Matrix[i][j]==1)
                    {
                        v1.push_back(j);
                    }
                }
                listaAdiacenta.push_back(v1);
            }
        QString filename = "ListaDeAdiacenta.txt";
        QFile file(filename);
        file.open(QIODevice::WriteOnly);
        QTextStream out(&file);
        out <<"Lista de adiacenta\n"<<g.getWantedNrNodes()<< " noduri\n";
        file.close();

        file.open(QIODevice::Append);
        for(int i=0;i<g.getWantedNrNodes();i++)
        {
            QTextStream out(&file);
            out<<i<<" : ";
            for(int j=0;j<listaAdiacenta[i].size();j++)
            {
                out<<listaAdiacenta[i][j]<<" ";
            }
            out<<"\n";
        }
        file.close();
    }
}

//deseneaza arcul cu sageata
void DrawLineWithArrow(QPainter& painter, QPoint start, QPoint end)
{
  painter.setRenderHint(QPainter::Antialiasing, true);

  qreal arrowSize = 15; // size of head
  painter.setPen(Qt::black);
  painter.setBrush(Qt::black);

  QLineF line(end, start);

  double angle = std::atan2(-line.dy(), line.dx());
  QPointF arrowP1 = line.p1() + QPointF(sin(angle + M_PI / 3) * arrowSize,
                                        cos(angle + M_PI / 3) * arrowSize);
  QPointF arrowP2 = line.p1() + QPointF(sin(angle + M_PI - M_PI / 3) * arrowSize,
                                        cos(angle + M_PI - M_PI / 3) * arrowSize);

  QPolygonF arrowHead;
  arrowHead.clear();
  arrowHead << line.p1() << arrowP1 << arrowP2;
  painter.drawLine(line);
  painter.drawPolygon(arrowHead);

}

void MainWindow::paintEvent(QPaintEvent *event)
{
    if (g.getNumberofNodes())
    {
        QPainter p(this);
        std::vector<Node> noduri = g.GetNoduri();
        for(auto& nod: noduri)
        {
            QRect r(nod.getPoint().x()-10,nod.getPoint().y()-10, 20,20);
            p.drawEllipse(r);
            p.drawText(nod.getPoint(), QString::number(nod.getNumber()));
        }
        std::vector<Arc> arce = g.GetArce();
        for(auto& arc: arce)
        {
            DrawLineWithArrow(p,arc.getFirstPoint().getPoint(), arc.getSecondPoint().getPoint());
        }

        if (drawNode)
        {
            Node n = g.GetLastNode();
            p.setPen(QPen(Qt::red));//il tine pe ultimul nod pus la culoarea rosie
            QRect r(n.getPoint().x()-10,n.getPoint().y()-10, 20,20);
            p.drawEllipse(r);
            p.drawText(n.getPoint(), QString::number(n.getNumber()));
        }
        else if (drawArc)
        {
            DrawLineWithArrow(p,arce[arce.size()-1].getFirstPoint().getPoint(), arce[arce.size()-1].getSecondPoint().getPoint());
        }
    }
    g.clearArce();
    g.clearNoduri();
    g.clearMatrix();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_SaveGraf_released()
{

}

void MainWindow::doPaths()
{
    yesPath=false;
    yesCycle=false;
    yesPath=true;
}

void MainWindow::doCycles()
{
    yesPath=false;
    yesCycle=false;
    yesCycle=true;
}

void MainWindow::on_pushButton_clicked()
{
    QString input = ui->lineEdit->text();
    int n = 0, nrD=0 , nrC=0;
    n = input.toInt();
    if(n!=0)
        ui->lineEdit->setText("Ok");
    else
        ui->lineEdit->setText("Not ok");
   g.setWantedNrNodes(n);

   input = ui->lineEdit_2->text();
   nrD = input.toInt();
   if(nrD!=0)
       ui->lineEdit_2->setText("Ok");
   else
       ui->lineEdit_2->setText("Not ok");
   g.setWantedPaths(nrD);

   input = ui->lineEdit_3->text();
   nrC = input.toInt();
   if(nrC!=0)
       ui->lineEdit_3->setText("Ok");
   else
       ui->lineEdit_3->setText("Not ok");
   g.setWantedCycles(nrC);
}

void MainWindow::on_pushButton_2_clicked()
{
    if(ui->radioButton->isChecked())
    {
        QMessageBox::information(this,"Optiune","DRUMURI");
        doPaths();
    }
    if(ui->radioButton_2->isChecked())
    {
        QMessageBox::information(this,"Optiune","CICLURI");
        doCycles();
    }
    if(ui->radioButton_3->isChecked())
    {
        QMessageBox::information(this,"Optiune","DOAR NODURI");
        yesPath=false;
        yesCycle=false;
    }
}

void MainWindow::on_pushButton_4_clicked()
{
    QMessageBox::information(this,"Fisier","Se genereaza n drumuri si n cicluri");

    QString filename = "nPaths.txt";
    QFile file(filename);
    file.open(QIODevice::WriteOnly);
    QTextStream out(&file);
    out<<"Generarea celor n drumuri : \n\n";
    file.close();

    std::vector<std::vector<int>> auxMatrix;
    for(int j=0;j<g.getWantedPaths();j++)
    {
        g.Paths();
        auxMatrix=g.GetMatrix();

        file.open(QIODevice::Append);
        QTextStream out(&file);
        out<<"Drumul "<<j<<"\n";
        for(int i=0;i<g.getWantedNrNodes();i++)
        {
            out <<i << " ";
        }
        for(int i=0;i<g.getWantedNrNodes();i++)
        {
            out<<"\n";
            for(int j=0;j<g.getWantedNrNodes();j++)
            {
                out<<auxMatrix[i][j]<<" ";
            }
        }
        out<<"\n";
        file.close();
        auxMatrix.clear();
        g.clearMatrix();
    }
    QString filename_2 = "nCycles.txt";
    QFile file_2(filename_2);
    file_2.open(QIODevice::WriteOnly);
    QTextStream out_2(&file_2);
    out_2<<"Generarea celor n cicluri : \n\n";
    file_2.close();

    for(int j=0;j<g.getWantedCycles();j++)
    {
        g.Cycles();
        auxMatrix=g.GetMatrix();

        file_2.open(QIODevice::Append);
        QTextStream out_2(&file_2);
        out_2<<"Ciclul "<<j<<"\n";
        for(int i=0;i<g.getWantedNrNodes();i++)
        {
            out_2 <<i << " ";
        }
        for(int i=0;i<g.getWantedNrNodes();i++)
        {
            out_2<<"\n";
            for(int j=0;j<g.getWantedNrNodes();j++)
            {
                out_2<<auxMatrix[i][j]<<" ";
            }
        }
        out_2<<"\n";
        file_2.close();
        auxMatrix.clear();
        g.clearMatrix();
    }
}
