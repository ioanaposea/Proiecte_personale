#ifndef GRAF_H
#define GRAF_H
#include "Node.h"
#include "Arc.h"
#include <QFile>

#include <iostream>
#include <vector>
#include <random>
#include <QApplication>
#include <QDebug>

class Graf
{
    int nrNodes = 0, nrPaths=0, nrCycles=0;
    std::vector<Node> noduri;
    std::vector<Arc> arce;
    std::vector<std::vector<int>> matrix;

public:
    std::vector<Arc> GetArce();
    void clearArce();

    std::vector<Node> GetNoduri();
    void clearNoduri();

    void AddNod(Node n);
    void AddArc(Arc a);

    Node GetLastNode();
    int getNumberofNodes();
    void setWantedNrNodes(int aux);
    int getWantedNrNodes();

    void setWantedPaths(int aux);
    int getWantedPaths();

    void setWantedCycles(int aux);
    int getWantedCycles();

    void Paths();
    void Cycles();

    std::vector<std::vector<int>> GetMatrix();
    void clearMatrix();
};
#endif // GRAF_H
