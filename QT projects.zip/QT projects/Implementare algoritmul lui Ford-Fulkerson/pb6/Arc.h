#ifndef ARC_H
#define ARC_H

#include "Node.h"
class Arc
{
    Node firstNode, secondNode;
    int capacity;
    QString culoare;

public:
    Arc(Node n1, Node n2);
    Node getFirstPoint();
    Node getSecondPoint();
    int getCapacity();
    QString getCuloare();
    void setCuloare(QString c);
};
#endif // ARC_H
