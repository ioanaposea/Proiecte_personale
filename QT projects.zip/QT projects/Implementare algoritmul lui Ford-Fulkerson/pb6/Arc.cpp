#include "Arc.h"
#include <time.h>

Arc::Arc(Node n1, Node n2)
{
    firstNode = n1;
    secondNode = n2;

    srand (time(NULL));
    //numere intre 1 si 15
    capacity = rand() % 15 + 1;

    culoare = "black";
}

Node Arc::getFirstPoint()
{
    return firstNode;
}

Node Arc::getSecondPoint()
{
    return secondNode;
}

int Arc::getCapacity()
{
    return capacity;
}

void Arc::setCuloare(QString c)
{
    culoare = c;
}

QString Arc::getCuloare()
{
    return culoare;
}
