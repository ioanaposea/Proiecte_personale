#ifndef GRAF_H
#define GRAF_H
#include "Node.h"
#include "Arc.h"
#include<iostream>
#include<QDebug>
#include<queue>
#include<cmath>

class Graf
{
    std::vector<Node> noduri;
    std::vector<Arc> arce;
    std::vector<std::vector<int>> matriceCosturi;
    std::vector<std::vector<int>> copieMatCosturi;
    //std::vector<std::vector<Node>> listaAdiacenta;
public:
    void GenerareMatriceCosturi();
    //void GenerareListaAdiacenta();
    std::vector<Arc> GetArce();
    std::vector<Node> GetNoduri();
    void AddNod(Node n);
    void AddArc(Arc a);
    void DrawGraf(QPainter *p);
    Node GetLastNode();
    int getNumberofNodes();
    bool BFS(int s, int t, std::vector<int>& parinte);
    void dfs(int s, std::vector<bool>& vizitate);
    int fordFulkerson(int s, int t);
    void resetGraf();
};
#endif // GRAF_H
