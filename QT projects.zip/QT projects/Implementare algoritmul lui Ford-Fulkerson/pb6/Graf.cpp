#include "Graf.h"

void Graf::GenerareMatriceCosturi()
{
    matriceCosturi.clear();

    std::vector<int> row;
    for(int i=0;i<getNumberofNodes();i++)
        row.push_back(0);
    for(int i=0;i<getNumberofNodes();i++)
        matriceCosturi.push_back(row);

    for(auto& it: arce)
    {
        matriceCosturi[it.getFirstPoint().getNumber()][it.getSecondPoint().getNumber()] = it.getCapacity();
    }

    //    std::cout<<"\n \n matrice noua \n";
    //    for(int i=0;i<getNumberofNodes();i++)
    //    {
    //        for(int j=0;j<getNumberofNodes();j++)
    //            std::cout<<matriceCosturi[i][j]<<" ";
    //        std::cout<<"\n";
    //    }
}

std::vector<Arc> Graf::GetArce()
{
    return arce;
}

std::vector<Node> Graf::GetNoduri()
{
    return noduri;
}

void Graf::AddNod(Node n)
{
    n.setNumber(noduri.size());
    noduri.push_back(n);
}

void Graf::AddArc(Arc n)
{
    for(int i=0;i<arce.size();i++)
        if(arce[i].getFirstPoint().getNumber()==n.getFirstPoint().getNumber() && arce[i].getSecondPoint().getNumber()==n.getSecondPoint().getNumber())
            return;
    arce.push_back(n);
}

Node Graf::GetLastNode()
{
    return noduri[noduri.size()-1];
}

int Graf::getNumberofNodes()
{
    return noduri.size();
}

bool Graf::BFS(int s, int t, std::vector<int>& parinte)
{
    std::vector<bool> vizitate;
    for(int i=0;i<getNumberofNodes();i++)
        vizitate.push_back(false);

    std::queue<int> queue;
    queue.push(s);
    vizitate[s] = true;
    parinte[s] = -1;

    while (!queue.empty())
    {
        int u = queue.front();
        queue.pop();

        for (int v = 0; v < getNumberofNodes(); v++)
        {
            if (vizitate[v] == false && copieMatCosturi[u][v] > 0)
            {
                if (v == t)
                {
                    parinte[v] = u;
                    return true;
                }

                queue.push(v);
                parinte[v] = u;
                vizitate[v] = true;
            }
        }
    }

    //nu a putut ajunge la nodul sToc
    return false;
}

void Graf::dfs(int s, std::vector<bool>& vizitate)
{
    vizitate[s] = true;
    for (int i = 0; i < getNumberofNodes(); i++)
        if (!vizitate[i] && copieMatCosturi[s][i])
            dfs(i, vizitate);
}

int Graf::fordFulkerson(int s, int t)
{
    int u, v;

    //pentru capacitatea reziduala
    copieMatCosturi = matriceCosturi;

    std::vector<int> parinte;
    for(int i=0;i<getNumberofNodes();i++)
        parinte.push_back(-1);

    int flux_maxim = 0;

    while (BFS(s, t, parinte))
    {
        int flux_drum = INT_MAX;
        for (v = t; v != s; v = parinte[v])
        {
            u = parinte[v];
            flux_drum = std::min(flux_drum, copieMatCosturi[u][v]);
        }

        // reface capacitatea reziduala
        for (v = t; v != s; v = parinte[v])
        {
            u = parinte[v];
            copieMatCosturi[u][v] -= flux_drum;
            copieMatCosturi[v][u] += flux_drum;
        }

        flux_maxim += flux_drum;
    }

    std::vector<bool> vizitate;
    for(int i=0;i<getNumberofNodes();i++)
        vizitate.push_back(false);

    dfs(s, vizitate);

    for (int i = 0; i < getNumberofNodes(); i++)
        for (int j = 0; j < getNumberofNodes(); j++)
            if (vizitate[i] && !vizitate[j] && matriceCosturi[i][j])
                for(auto& it:arce)
                    if(it.getFirstPoint().getNumber()==i &&it.getSecondPoint().getNumber()==j)
                        it.setCuloare("green");

    return flux_maxim;
}

void Graf::resetGraf()
{
    for(auto& it:arce)
    {
        it.setCuloare("black");
    }
}
