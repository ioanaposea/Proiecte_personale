﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Hangman.Models
{
    public enum Category
    {
        None,
        All,
        Cars,
        Movies,
        TvShows,
        Countries
    }

    [Serializable]
    public class Game : INotifyPropertyChanged
    {

        private int _level;
        private int _mistakes;
        private Category _categoryType;
        private string _wordOnDisplay;
        private string _wordToGuess;
        private int _timeLeft;
        private bool _savedGame;

        [XmlAttribute]
        public int Level
        {
            get { return _level; }
            set { _level = value; OnPropertyChanged("Level"); }
        }
        [XmlAttribute]
        public int Mistakes
        {
            get { return _mistakes; }
            set { _mistakes = value; OnPropertyChanged("Mistakes"); }
        }
        [XmlAttribute]
        public Category CategoryType
        {
            get { return _categoryType; }
            set { _categoryType = value; OnPropertyChanged("CategoryType"); }
        }
        [XmlAttribute]
        public string WordOnDisplay
        {
            get { return _wordOnDisplay; }
            set { _wordOnDisplay = value; OnPropertyChanged("WordOnDisplay"); }
        }
        [XmlAttribute]
        public string WordToGuess
        {
            get { return _wordToGuess; }
            set { _wordToGuess = value; OnPropertyChanged("WordToGuess"); }
        }
        [XmlAttribute]
        public int TimeLeft
        {
            get { return _timeLeft; }
            set { _timeLeft = value; OnPropertyChanged("TimeLeft"); }
        }
        [XmlAttribute]
        public bool SavedGame
        {
            get { return _savedGame; }
            set { _savedGame = value; OnPropertyChanged("SavedGame"); }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

    }
}
