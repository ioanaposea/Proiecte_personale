﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Hangman.Models
{

    [Serializable]
    public class User : INotifyPropertyChanged
    {

        private string _username;
        private string _iconPath;
        private Game _gameSaved;
        private Statistics _statistic;

        [XmlElement]
        public string Username
        {
            get { return _username; }
            set { _username = value; OnPropertyChanged("Username"); }
        }
        [XmlElement]
        public string IconPath
        {
            get { return _iconPath; }
            set { _iconPath = value; OnPropertyChanged("IconPath"); }
        }
        [XmlElement]
        public Game GameSaved
        {
            get { return _gameSaved; }
            set { _gameSaved = value; OnPropertyChanged("GameSaved"); }
        }
        [XmlElement]
        public Statistics Statistic
        {
            get { return _statistic; }
            set { _statistic = value; OnPropertyChanged("WonGames"); }
        }

        public User() { }



        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
