﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hangman.Models
{
    public class Help
    {
        public Help() { }

        public static bool CanAddUser(string usrname, Users users)
        {
            foreach (var user in users.List)
            {
                if (user.Username == usrname)
                {
                    return false;
                }
            }
            return true;
        }


    }
}
