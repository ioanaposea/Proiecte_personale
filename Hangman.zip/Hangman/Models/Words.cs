﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Hangman.Models
{
    [Serializable]
    public class Words
    {
        private SerializationHelp serialization = new SerializationHelp();
        [XmlArray]
        public ObservableCollection<string> Cars { get; set; }
        [XmlArray]
        public ObservableCollection<string> Movies { get; set; }
        [XmlArray]
        public ObservableCollection<string> TvShows { get; set; }
        [XmlArray]
        public ObservableCollection<string> Countries { get; set; }
        public int TotalCategories = 4;
        public Words()
        {
            Cars = new ObservableCollection<string>();
            Movies = new ObservableCollection<string>();
            TvShows = new ObservableCollection<string>();
            Countries = new ObservableCollection<string>();
        }

        public void AddWords()
        {
            Cars = new ObservableCollection<string>();
            Cars.Add("FORD");
            Cars.Add("MERCEDES");
            Cars.Add("AUDI");
            Cars.Add("OPEL");
            Cars.Add("DACIA");
            Cars.Add("VOLKSWAGEN");
            Cars.Add("FERRARI");
            Cars.Add("HONDA");
            Cars.Add("SUBARU");
            Cars.Add("TOYOTA");
            Cars.Add("HYUNDAI");
            Cars.Add("RENAULT");
            Cars.Add("RANGE ROVER");
            Cars.Add("LAND ROVER");
            Cars.Add("PEUGEOT");
            Cars.Add("ASTON MARTIN");
            Cars.Add("LAMBORGHINI");
            Cars.Add("BUGATTI");
            Cars.Add("BENTLEY");
            Cars.Add("PORSCHE");

            Movies = new ObservableCollection<string>();
            Movies.Add("THE GODFATHER");
            Movies.Add("PULP FICTION");
            Movies.Add("INCEPTION");
            Movies.Add("FORREST GUMP");
            Movies.Add("THE MATRIX");
            Movies.Add("GOODFELLAS");
            Movies.Add("INTERSTELLAR");
            Movies.Add("STAR WARS");
            Movies.Add("PARASITE");
            Movies.Add("THE LION KING");
            Movies.Add("CASABLANCA");
            Movies.Add("FINDING NEMO");
            Movies.Add("BATMAN");


            TvShows = new ObservableCollection<string>();
            TvShows.Add("BRIDGERTON");
            TvShows.Add("STRANGER THINGS");
            TvShows.Add("THE WALKING DEAD");
            TvShows.Add("PEAKY BLINDERS");
            TvShows.Add("KILLING EVE");
            TvShows.Add("GAME OF THRONES");
            TvShows.Add("BREAKING BAD");
            TvShows.Add("EUPHORIA");
            TvShows.Add("OUTLANDER");
            TvShows.Add("THIS IS US");
            TvShows.Add("FRIENDS");
            TvShows.Add("MAID");
            TvShows.Add("ANNE WITH AN E");
            TvShows.Add("SHERLOCK");
            TvShows.Add("REIGN");
            TvShows.Add("EMILY IN PARIS");
            TvShows.Add("THE GOOD PLACE");
            TvShows.Add("MODERN FAMILY");
            TvShows.Add("UNORTHODOX");


            Countries = new ObservableCollection<string>();
            Countries.Add("USA");
            Countries.Add("MEXICO");
            Countries.Add("CANADA");
            Countries.Add("SWITZERLAND");
            Countries.Add("LIECHTENSTEIN");
            Countries.Add("ROMANIA");
            Countries.Add("BULGARIA");
            Countries.Add("MALDIVES");
            Countries.Add("SEYCHELLES");
            Countries.Add("SAUDI ARABIA");
            Countries.Add("CHINA");
            Countries.Add("UKRAINE");
            Countries.Add("HUNGARY");
            Countries.Add("MADAGASCAR");
            Countries.Add("MOZAMBIQUE");
            Countries.Add("EAST TIMOR");
            Countries.Add("TUVALU");
            Countries.Add("AUSTRALIA");
            Countries.Add("SOLOMON ISLANDS");
            Countries.Add("MICRONESIA");
            Countries.Add("PHILIPPINES");
            Countries.Add("NEPAL");
            Countries.Add("KYRGYZSTAN");
            Countries.Add("TAKJIKISTAN");
            Countries.Add("GEORGIA");
            Countries.Add("SIERRA LEONE");

        }
    }
}
