﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Hangman.Models
{
    [Serializable]
    public class Statistics : INotifyPropertyChanged
    {
        private int _allWon;
        private int _allLost;
        private int _carsWon;
        private int _carsLost;
        private int _moviesWon;
        private int _moviesLost;
        private int _tvShowsWon;
        private int _tvShowsLost;
        private int _countriesWon;
        private int _countriesLost;

        [XmlElement]
        public int AllWon
        {
            get { return _allWon; }
            set { _allWon = value; OnPropertyChanged("WonGames"); }
        }
        [XmlElement]
        public int CarsWon
        {
            get { return _carsWon; }
            set { _carsWon = value; OnPropertyChanged("WonGames"); }
        }
        [XmlElement]
        public int MoviesWon
        {
            get { return _moviesWon; }
            set { _moviesWon = value; OnPropertyChanged("WonGames"); }
        }
        [XmlElement]
        public int TvShowsWon
        {
            get { return _tvShowsWon; }
            set { _tvShowsWon = value; OnPropertyChanged("WonGames"); }
        }
        [XmlElement]
        public int CountriesWon
        {
            get { return _countriesWon; }
            set { _countriesWon = value; OnPropertyChanged("WonGames"); }
        }
        [XmlElement]
        public int AllLost
        {
            get { return _allLost; }
            set { _allLost = value; OnPropertyChanged("WonGames"); }
        }
        [XmlElement]
        public int CarsLost
        {
            get { return _carsLost; }
            set { _carsLost = value; OnPropertyChanged("WonGames"); }
        }
        [XmlElement]
        public int MoviesLost
        {
            get { return _moviesLost; }
            set { _moviesLost = value; OnPropertyChanged("WonGames"); }
        }
        [XmlElement]
        public int TvShowsLost
        {
            get { return _tvShowsLost; }
            set { _tvShowsLost = value; OnPropertyChanged("WonGames"); }
        }
        [XmlElement]
        public int CountriesLost
        {
            get { return _countriesLost; }
            set { _countriesLost = value; OnPropertyChanged("WonGames"); }
        }
        public Statistics()
        {
            AllLost = 0;
            AllWon = 0;
            CarsLost = 0;
            MoviesLost = 0;
            TvShowsLost = 0;
            CountriesLost = 0;
            CarsWon = 0;
            MoviesWon = 0;
            TvShowsWon = 0;
            CountriesWon = 0;
        }

        public int WonGames
        {
            get { return AllWon + CarsWon + MoviesWon + TvShowsWon + CountriesWon; }
        }

        public int LostGames
        {
            get { return AllLost + CarsLost + MoviesLost + TvShowsLost + CountriesLost; }
        }

        public int TotalGames
        {
            get { return WonGames + LostGames; }
        }


        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
