﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;

namespace Hangman.Models
{
    public class Images : INotifyPropertyChanged
    {
        public ObservableCollection<BitmapImage> UserIcon { get; set; }
        public ObservableCollection<BitmapImage> HangmanMistakes { get; set; }

        public Images()
        {

            UserIcon = new ObservableCollection<BitmapImage>();
            UserIcon.Add(new BitmapImage(new Uri(@"/userPhotos/icon1.png", UriKind.Relative)));
            UserIcon.Add(new BitmapImage(new Uri(@"/userPhotos/icon2.png", UriKind.Relative)));
            UserIcon.Add(new BitmapImage(new Uri(@"/userPhotos/icon3.png", UriKind.Relative)));
            UserIcon.Add(new BitmapImage(new Uri(@"/userPhotos/icon4.png", UriKind.Relative)));
            UserIcon.Add(new BitmapImage(new Uri(@"/userPhotos/icon5.png", UriKind.Relative)));

            HangmanMistakes = new ObservableCollection<BitmapImage>();
            HangmanMistakes.Add(new BitmapImage(new Uri(@"/userPhotos/Hangman.png", UriKind.Relative)));
            HangmanMistakes.Add(new BitmapImage(new Uri(@"/userPhotos/Hangman1.png", UriKind.Relative)));
            HangmanMistakes.Add(new BitmapImage(new Uri(@"/userPhotos/Hangman2.png", UriKind.Relative)));
            HangmanMistakes.Add(new BitmapImage(new Uri(@"/userPhotos/Hangman3.png", UriKind.Relative)));
            HangmanMistakes.Add(new BitmapImage(new Uri(@"/userPhotos/Hangman4.png", UriKind.Relative)));
            HangmanMistakes.Add(new BitmapImage(new Uri(@"/userPhotos/Hangman5.png", UriKind.Relative)));

        }

        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged<T>(ref T property, T value, [CallerMemberName] string propertyName = "")
        {
            property = value;
            var handler = PropertyChanged;
            if (handler != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
