﻿using Hangman.Models;
using Hangman.View;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace Hangman.ViewModels
{
    public class HangmanGameViewModel : INotifyPropertyChanged
    {
        private SerializationHelp serialization = new SerializationHelp();
        private ObservableCollection<ButtonModel> _buttons = new ObservableCollection<ButtonModel>();

        private User _user;
        private Users _users;

        private Words _words = new Words();
        private Images _Images = new Images();
        private BitmapImage _currentHangImage;

        private DispatcherTimer _timer = new DispatcherTimer();
        private int duration;
        private string _time;

        private bool firstCreationOfWord = true;
        private bool resumeGame = false;

        public BitmapImage CurrentHangImage
        {
            get { return _currentHangImage; }
            set { OnPropertyChanged(ref _currentHangImage, value); }
        }
        public DispatcherTimer Timer
        {
            get { return _timer; }
            set { OnPropertyChanged(ref _timer, value); }
        }
        public string Time
        {
            get { return _time; }
            set { OnPropertyChanged(ref _time, value); }
        }
        public User User
        {
            get { return _user; }
            set { OnPropertyChanged(ref _user, value); }
        }
        public Users Users
        {
            get { return _users; }
            set { OnPropertyChanged(ref _users, value); }
        }
        public Words Words
        {
            get { return _words; }
            set { OnPropertyChanged(ref _words, value); }
        }
        public ObservableCollection<ButtonModel> Buttons
        {
            get { return _buttons; }
            set { OnPropertyChanged(ref _buttons, value); }
        }

        public HangmanGameViewModel() { }
        public HangmanGameViewModel(User user, bool gameResumed)
        {
            User = user;
            Words.AddWords();
            serialization.SerializeWords(@"..\..\..\Files\Words.xml", Words);
            Words = serialization.DeserializeWords(@"..\..\..\Files\Words.xml");
            Users = serialization.DeserializeUsers(@"..\..\..\Files\Users.xml");

            foreach (var userInList in Users.List)
            {
                if (userInList.Username == User.Username)
                {
                    Users.List.Remove(userInList);
                    Users.List.Add(User);
                    break;
                }
            }

            serialization.SerializeUsers(@"..\..\..\Files\Users.xml", Users);
            Users = serialization.DeserializeUsers(@"..\..\..\Files\Users.xml");

            if (!gameResumed)
            {
                duration = 40;
                ChooseWord(User.GameSaved.CategoryType);
                User.GameSaved.Mistakes = 0;
                User.GameSaved.Level = 1;
                createWord(User.GameSaved.WordToGuess);
                CurrentHangImage = _Images.HangmanMistakes[0];
            }
            else
            {
                duration = User.GameSaved.TimeLeft;
                CurrentHangImage = _Images.HangmanMistakes[User.GameSaved.Mistakes];
                User.GameSaved.SavedGame = false;
                firstCreationOfWord = false;
            }

            AddButtons();
            Timer.Tick += new EventHandler(count_down);
            Timer.Interval = TimeSpan.FromSeconds(1);
            Timer.Start();
        }
        private void AddButtons()
        {
            Buttons.Add(new ButtonModel('Q'));
            Buttons.Add(new ButtonModel('W'));
            Buttons.Add(new ButtonModel('E'));
            Buttons.Add(new ButtonModel('R'));
            Buttons.Add(new ButtonModel('T'));
            Buttons.Add(new ButtonModel('Y'));
            Buttons.Add(new ButtonModel('U'));
            Buttons.Add(new ButtonModel('I'));
            Buttons.Add(new ButtonModel('O'));
            Buttons.Add(new ButtonModel('P'));
            Buttons.Add(new ButtonModel('A'));
            Buttons.Add(new ButtonModel('S'));
            Buttons.Add(new ButtonModel('D'));
            Buttons.Add(new ButtonModel('F'));
            Buttons.Add(new ButtonModel('G'));
            Buttons.Add(new ButtonModel('H'));
            Buttons.Add(new ButtonModel('J'));
            Buttons.Add(new ButtonModel('K'));
            Buttons.Add(new ButtonModel('L'));
            Buttons.Add(new ButtonModel('Z'));
            Buttons.Add(new ButtonModel('X'));
            Buttons.Add(new ButtonModel('C'));
            Buttons.Add(new ButtonModel('V'));
            Buttons.Add(new ButtonModel('B'));
            Buttons.Add(new ButtonModel('N'));
            Buttons.Add(new ButtonModel('M'));
        }

        public void LetterPressed(char name)
        {
            bool foundLetter = false;
            char letter = name;

            foreach (var btn in Buttons)
            {
                if (btn.Name == name)
                {
                    if (btn.Enabled == false)
                        return;

                    btn.Enabled = false;

                    for (int index = 0; index < User.GameSaved.WordToGuess.Length; ++index)
                    {
                        if (User.GameSaved.WordToGuess[index] == letter)
                        {
                            string word = User.GameSaved.WordOnDisplay;
                            word = new Regex(@"\s\s\s").Replace(word, " ");
                            word = new Regex(@"＿\s").Replace(word, "＿");

                            StringBuilder newString = new StringBuilder(word);
                            newString[index] = letter;

                            createWord(newString.ToString());
                            foundLetter = true;
                        }
                    }

                    if (!Regex.Match(User.GameSaved.WordOnDisplay, "＿").Success)
                    {
                        User.GameSaved.Level += 1;
                        if (User.GameSaved.Level > 5)
                        {
                            switch (User.GameSaved.CategoryType)
                            {
                                case Category.All:
                                    User.Statistic.AllWon += 1;
                                    break;
                                case Category.Cars:
                                    User.Statistic.CarsWon += 1;
                                    break;
                                case Category.Movies:
                                    User.Statistic.MoviesWon += 1;
                                    break;
                                case Category.TvShows:
                                    User.Statistic.TvShowsWon += 1;
                                    break;
                                case Category.Countries:
                                    User.Statistic.CountriesWon += 1;
                                    break;
                                default:
                                    break;
                            }

                            Users = serialization.DeserializeUsers(@"..\..\..\Files\Users.xml");

                            foreach (var userInList in Users.List)
                            {
                                if (userInList.Username == User.Username)
                                {
                                    userInList.Statistic = User.Statistic;
                                }
                            }
                            serialization.SerializeUsers(@"..\..\..\Files\Users.xml", Users);
                            MessageBoxYesNo("Congrats", "YOU WON\nDo you want to start a new game on the same category?", MessageBoxImage.Information);
                            return;
                        }
                        NewLevelGame();
                    }

                    if (foundLetter)
                        return;

                    if (User.GameSaved.Mistakes < 4)
                    {
                        CurrentHangImage = _Images.HangmanMistakes[++User.GameSaved.Mistakes];
                        return;
                    }
                    else
                    {
                        switch (User.GameSaved.CategoryType)
                        {
                            case Category.All:
                                User.Statistic.AllLost += 1;
                                break;
                            case Category.Cars:
                                User.Statistic.CarsLost += 1;
                                break;
                            case Category.Movies:
                                User.Statistic.MoviesLost += 1;
                                break;
                            case Category.TvShows:
                                User.Statistic.TvShowsLost += 1;
                                break;
                            case Category.Countries:
                                User.Statistic.CountriesLost += 1;
                                break;
                            default:
                                break;
                        }

                        Users = serialization.DeserializeUsers(@"..\..\..\Files\Users.xml");

                        foreach (var userInList in Users.List)
                        {
                            if (userInList.Username == User.Username)
                            {
                                userInList.Statistic = User.Statistic;
                            }
                        }

                        serialization.SerializeUsers(@"..\..\..\Files\Users.xml", Users);
                        CurrentHangImage = _Images.HangmanMistakes[++User.GameSaved.Mistakes];
                        MessageBoxYesNo("We are sorry", "YOU LOST\nDo you want to start a new game on the same category?", MessageBoxImage.Error);
                    }

                    break;
                }
            }
        }

        private void NewLevelGame()
        {
            User.GameSaved.WordOnDisplay = "";

            foreach (var button in Buttons)
                button.Enabled = true;

            duration = 40;

            ChooseWord(User.GameSaved.CategoryType);
            User.GameSaved.Mistakes = 0;
            //User.GameSaved.Level = 1;
            firstCreationOfWord = true;
            createWord(User.GameSaved.WordToGuess);
            CurrentHangImage = _Images.HangmanMistakes[0];

            CurrentHangImage = _Images.HangmanMistakes[User.GameSaved.Mistakes];

            Timer.Start();
        }

        private void MessageBoxYesNo(string title, string details, MessageBoxImage messageBoxImage)
        {
            Timer.Stop();
            MessageBoxResult result = MessageBox.Show(details, title, MessageBoxButton.YesNo, messageBoxImage);

            switch (result)
            {
                case MessageBoxResult.Yes:
                    {
                        User.GameSaved.Level = 1;
                        NewLevelGame();
                        break;
                    }
                case MessageBoxResult.No:
                    {
                        User.GameSaved.Mistakes = 0;
                        User.GameSaved.Level = 1;

                        PlayNewOrResumeWindow playNewOrResumeWindow = new PlayNewOrResumeWindow();
                        PlayNewOrResumeViewModel playNewOrResumeViewModel = new PlayNewOrResumeViewModel(User);

                        playNewOrResumeWindow.DataContext = playNewOrResumeViewModel;
                        App.Current.MainWindow.Close();
                        App.Current.MainWindow = playNewOrResumeWindow;
                        playNewOrResumeWindow.Show();
                        break;
                    }

            }

        }

        public void createWord(string word)
        {
            word = new Regex(@"\s").Replace(word, "   ");
            if (firstCreationOfWord)
                User.GameSaved.WordOnDisplay = new Regex(@"\S").Replace(word, "＿ ");
            else
                User.GameSaved.WordOnDisplay = new Regex(@"＿").Replace(word, "＿ ");

            firstCreationOfWord = false;
        }

        private void ChooseWord(Category cat)
        {
            var random = new Random();
            switch (cat)
            {
                case Models.Category.All:
                    int randomCat = random.Next(Words.TotalCategories);
                    switch (randomCat)
                    {
                        case 0:
                            User.GameSaved.WordToGuess = Words.Cars[random.Next(Words.Cars.Count)];
                            break;
                        case 1:
                            User.GameSaved.WordToGuess = Words.Movies[random.Next(Words.Movies.Count)];
                            break;
                        case 2:
                            User.GameSaved.WordToGuess = Words.TvShows[random.Next(Words.TvShows.Count)];
                            break;
                        case 3:
                            User.GameSaved.WordToGuess = Words.Countries[random.Next(Words.Countries.Count)];
                            break;
                        default:
                            break;
                    }
                    break;
                case Models.Category.Cars:
                    User.GameSaved.WordToGuess = Words.Cars[random.Next(Words.Cars.Count)];
                    break;
                case Models.Category.Movies:
                    User.GameSaved.WordToGuess = Words.Movies[random.Next(Words.Movies.Count)];
                    break;
                case Models.Category.TvShows:
                    User.GameSaved.WordToGuess = Words.TvShows[random.Next(Words.TvShows.Count)];
                    break;
                case Models.Category.Countries:
                    User.GameSaved.WordToGuess = Words.Countries[random.Next(Words.Countries.Count)];
                    break;
                default:
                    break;
            }
        }

        private void EndTime()
        {
            switch (User.GameSaved.CategoryType)
            {
                case Category.All:
                    _user.Statistic.AllLost += 1;
                    break;
                case Category.Cars:
                    _user.Statistic.CarsLost += 1;
                    break;
                case Category.Movies:
                    _user.Statistic.MoviesLost += 1;
                    break;
                case Category.TvShows:
                    _user.Statistic.TvShowsLost += 1;
                    break;
                case Category.Countries:
                    _user.Statistic.CountriesLost += 1;
                    break;
                default:
                    break;
            }

            Users = serialization.DeserializeUsers(@"..\..\..\Files\Users.xml");

            foreach (var userInList in Users.List)
            {
                if (userInList.Username == User.Username)
                {
                    userInList.Statistic = User.Statistic;
                    if (resumeGame)
                    {
                        userInList.GameSaved = new Game();
                    }
                }
            }

            serialization.SerializeUsers(@"..\..\..\Files\Users.xml", Users);
            MessageBoxYesNo("Oh", "TIME EXPIRED\nDo you want to start a new game on the same category?", MessageBoxImage.Warning);
        }

        private void count_down(object sender, EventArgs e)
        {

            if (duration == 0)
            {
                Timer.Stop();
                EndTime();
            }
            else if (duration > 0)
            {
                duration--;
                Time = duration.ToString();
            }
        }

        public void About()
        {
            AboutWindow about = new AboutWindow();
            about.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            about.Show();
        }

        private void lostCalculate()
        {
            switch (User.GameSaved.CategoryType)
            {
                case Category.All:
                    _user.Statistic.AllLost += 1;
                    break;
                case Category.Cars:
                    _user.Statistic.CarsLost += 1;
                    break;
                case Category.Movies:
                    _user.Statistic.MoviesLost += 1;
                    break;
                case Category.TvShows:
                    _user.Statistic.TvShowsLost += 1;
                    break;
                case Category.Countries:
                    _user.Statistic.CountriesLost += 1;
                    break;
                default:
                    break;
            }

            Users = serialization.DeserializeUsers(@"..\..\..\Files\Users.xml");

            foreach (var userInList in Users.List)
            {
                if (userInList.Username == User.Username)
                {
                    userInList.Statistic = User.Statistic;
                }
            }
            serialization.SerializeUsers(@"..\..\..\Files\Users.xml", Users);
        }

        public void Exit()
        {
            lostCalculate();
            Timer.Stop();

            MainWindow newMainWindow = new MainWindow();
            MainWindowViewModel newMainVwMdl = new MainWindowViewModel();

            newMainWindow.DataContext = newMainVwMdl;
            App.Current.MainWindow.Close();
            App.Current.MainWindow = newMainWindow;
            newMainWindow.Show();
        }

        public void StatisticsOpen()
        {
            lostCalculate();
            Timer.Stop();

            StatisticsWindow newMainWindow = new StatisticsWindow();
            StatisticsViewModel newMainVwMdl = new StatisticsViewModel(User.Username);

            newMainWindow.DataContext = newMainVwMdl;
            App.Current.MainWindow.Close();
            App.Current.MainWindow = newMainWindow;
            newMainWindow.Show();
        }

        private ICommand saveCommand;
        public ICommand SaveCommand
        {
            get
            {
                if (saveCommand == null)
                {
                    saveCommand = new CommandHelp(SaveGame);
                }
                return saveCommand;
            }
        }

        public void SaveGame(object param)
        {
            Timer.Stop();
            User.GameSaved.TimeLeft = duration;
            User.GameSaved.SavedGame = true;

            Users = serialization.DeserializeUsers(@"..\..\..\Files\Users.xml");
            foreach (var userInList in Users.List)
            {
                if (User.Username == userInList.Username)
                {
                    Users.List.Remove(userInList);
                    break;
                }
            }

            Users.List.Add(User);

            serialization.SerializeUsers(@"..\..\..\Files\Users.xml", Users);

            MainWindow mainWindow = new MainWindow();
            MainWindowViewModel mainWindowViewModel = new MainWindowViewModel();

            mainWindow.DataContext = mainWindowViewModel;
            App.Current.MainWindow.Close();
            App.Current.MainWindow = mainWindow;
            mainWindow.Show();
        }

        private ICommand openCommand;
        public ICommand OpenCommand
        {
            get
            {
                if (openCommand == null)
                {
                    openCommand = new CommandHelp(OpenGame);
                }
                return openCommand;
            }
        }

        public void OpenGame(object param)
        {
            if (User.GameSaved.SavedGame == false)
            {
                MessageBox.Show("YOU DON'T HAVE ANY GAME SAVED", "Information");
                return;
            }

            lostCalculate();
            Timer.Stop();
            HangmanGame hangmanGameWindow = new HangmanGame();
            HangmanGameViewModel hangmanGameVwMdl = new HangmanGameViewModel(_user, true);

            hangmanGameWindow.DataContext = hangmanGameVwMdl;
            App.Current.MainWindow.Close();
            App.Current.MainWindow = hangmanGameWindow;
            hangmanGameWindow.Show();
        }

        private ICommand newCommand;
        public ICommand NewCommand
        {
            get
            {
                if (newCommand == null)
                {
                    newCommand = new CommandHelp(NewGame);
                }
                return newCommand;
            }
        }

        public void NewGame(object param)
        {
            Timer.Stop();
            MessageBoxResult result = MessageBox.Show("Are you sure you want to start a new game?", "New game", MessageBoxButton.YesNo, MessageBoxImage.Question);

            switch (result)
            {
                case MessageBoxResult.Yes:
                    {
                        lostCalculate();

                        PlayNewOrResumeWindow playNewOrResumeWindow = new PlayNewOrResumeWindow();
                        PlayNewOrResumeViewModel playNewOrResumeViewModel = new PlayNewOrResumeViewModel(User);

                        playNewOrResumeWindow.DataContext = playNewOrResumeViewModel;
                        App.Current.MainWindow.Close();
                        App.Current.MainWindow = playNewOrResumeWindow;
                        playNewOrResumeWindow.Show();
                        break;
                    }
                case MessageBoxResult.No:
                    {
                        Timer.Start();
                        break;
                    }

            }
        }

        private void newCategoryGame(Category category)
        {
            Timer.Stop();
            MessageBoxResult result = MessageBox.Show("Are you sure you want to start a new game?", "New game", MessageBoxButton.YesNo, MessageBoxImage.Question);

            switch (result)
            {
                case MessageBoxResult.Yes:
                    {
                        lostCalculate();

                        User.GameSaved.Level = 1;
                        User.GameSaved.Mistakes = 0;
                        User.GameSaved.CategoryType = category;
                        User.GameSaved.SavedGame = false;

                        HangmanGame hangmanGame = new HangmanGame();
                        HangmanGameViewModel hangmanGameViewModel = new HangmanGameViewModel(User, false);

                        hangmanGame.DataContext = hangmanGameViewModel;
                        App.Current.MainWindow.Close();
                        App.Current.MainWindow = hangmanGame;
                        hangmanGame.Show();
                        break;
                    }
                case MessageBoxResult.No:
                    {
                        Timer.Start();
                        break;
                    }
            }
        }

        private ICommand newCommandCatAll;
        public ICommand NewCommandCatAll
        {
            get
            {
                if (newCommandCatAll == null)
                {
                    newCommandCatAll = new CommandHelp(NewGameCatAll);
                }
                return newCommandCatAll;
            }
        }
        public void NewGameCatAll(object param)
        {
            newCategoryGame(Models.Category.All);
        }

        private ICommand newCommandCatCars;
        public ICommand NewCommandCatCars
        {
            get
            {
                if (newCommandCatCars == null)
                {
                    newCommandCatCars = new CommandHelp(NewGameCatCars);
                }
                return newCommandCatCars;
            }
        }
        public void NewGameCatCars(object param)
        {
            newCategoryGame(Models.Category.Cars);
        }

        private ICommand newCommandCatMovies;
        public ICommand NewCommandCatMovies
        {
            get
            {
                if (newCommandCatMovies == null)
                {
                    newCommandCatMovies = new CommandHelp(NewGameCatMovies);
                }
                return newCommandCatMovies;
            }
        }
        public void NewGameCatMovies(object param)
        {
            newCategoryGame(Models.Category.Movies);
        }

        private ICommand newCommandCatTvShows;
        public ICommand NewCommandCatTvShows
        {
            get
            {
                if (newCommandCatTvShows == null)
                {
                    newCommandCatTvShows = new CommandHelp(NewGameCatTvShows);
                }
                return newCommandCatTvShows;
            }
        }
        public void NewGameCatTvShows(object param)
        {
            newCategoryGame(Models.Category.TvShows);
        }

        private ICommand newCommandCatCountries;
        public ICommand NewCommandCatCountries
        {
            get
            {
                if (newCommandCatCountries == null)
                {
                    newCommandCatCountries = new CommandHelp(NewGameCatCountries);
                }
                return newCommandCatCountries;
            }
        }
        public void NewGameCatCountries(object param)
        {
            newCategoryGame(Models.Category.Countries);
        }


        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged<T>(ref T property, T value, [CallerMemberName] string propertyName = "")
        {
            property = value;
            var handler = PropertyChanged;
            if (handler != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
