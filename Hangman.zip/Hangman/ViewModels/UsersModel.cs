﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using Hangman.Models;

namespace Hangman.ViewModels
{
    [Serializable]
    public class UsersModel : INotifyPropertyChanged
    {
        

        //public UsersModel()
        //{
        //    //List = new ObservableCollection<User>();
        //    List = serialization.DeserializeUsers("output.xml").List;
        //    //@"..\..\..\Files\Users.xml"
        //}
        //private User _currentUser = new User();
        //[XmlIgnore]
        //public User CurrentUser
        //{
        //    get { return _currentUser; }
        //    set { OnPropertyChanged(ref _currentUser, value); }
        //}

        //private ObservableCollection<User> _users = new ObservableCollection<User>();
        //[XmlArray]
        //public ObservableCollection<User> List
        //{
        //    get { return _users; }
        //    set { OnPropertyChanged(ref _users, value); }
        //}


        //public void readUsers()
        //{
        //    User user = new User();
        //    List.Add(user);
        //}

        //public void addUser(string username, string iconPath)
        //{
        //    //User user = new User(username, iconPath, false, 0, 0, 0, "", "", "", 0, 0);
        //    //Users.Add(user);

        //    //Console.WriteLine(user.Username);
        //}

        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged<T>(ref T property, T value, [CallerMemberName] string propertyName = "")
        {
            property = value;
            var handler = PropertyChanged;
            if (handler != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
