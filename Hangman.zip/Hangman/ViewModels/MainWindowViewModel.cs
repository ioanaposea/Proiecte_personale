﻿using Hangman.Models;
using Hangman.View;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Hangman.ViewModels
{
    [Serializable]
    public class MainWindowViewModel : INotifyPropertyChanged
    {
        private SerializationHelp serialization = new SerializationHelp();
        private Users _users = new Users();
        private User _selectedUser;

        public ObservableCollection<User> Users
        {
            get { return _users.List; }
        }


        public User SelectedUser
        {
            get { return _selectedUser; }
            set { OnPropertyChanged(ref _selectedUser, value); }
        }

        public MainWindowViewModel()
        {
            this._users = serialization.DeserializeUsers(@"..\..\..\Files\Users.xml");
        }

        public MainWindowViewModel(Users users)
        {
            this._users = users;
            serialization.SerializeUsers(@"..\..\..\Files\Users.xml", users);
        }

        public void PlayGame()
        {
            PlayNewOrResumeWindow hangmanGameWindow = new PlayNewOrResumeWindow();
            PlayNewOrResumeViewModel hangmanGameVwMdl = new PlayNewOrResumeViewModel(SelectedUser);

            hangmanGameWindow.DataContext = hangmanGameVwMdl;
            App.Current.MainWindow.Close();
            App.Current.MainWindow = hangmanGameWindow;
            hangmanGameWindow.Show();
        }

        public void AddNewUser()
        {
            NewUserWindow newUserWindow = new NewUserWindow();
            NewUserWindowViewModel newUserVwMdl = new NewUserWindowViewModel();

            newUserWindow.DataContext = newUserVwMdl;
            App.Current.MainWindow.Close();
            App.Current.MainWindow = newUserWindow;
            newUserWindow.Show();
        }

        public void DeleteUser()
        {
            foreach (var user in _users.List)
            {
                if (user.Username == SelectedUser.Username)
                {
                    _users.List.Remove(user);
                    break;
                }
            }

            SelectedUser = null;
            serialization.SerializeUsers(@"..\..\..\Files\Users.xml", _users);
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged<T>(ref T property, T value, [CallerMemberName] string propertyName = "")
        {
            property = value;
            var handler = PropertyChanged;
            if (handler != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
