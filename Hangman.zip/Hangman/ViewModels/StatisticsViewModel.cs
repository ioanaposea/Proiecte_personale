﻿using Hangman.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Hangman.ViewModels
{
    public class StatisticsViewModel
    {
        private SerializationHelp serialization = new SerializationHelp();
        private User _user;
        private Users _users;

        public User User
        {
            get { return _user; }
            set { OnPropertyChanged(ref _user, value); }
        }
        public Users Users
        {
            get { return _users; }
            set { OnPropertyChanged(ref _users, value); }
        }

        public StatisticsViewModel() { }
        public StatisticsViewModel(string username)
        {
            Users = serialization.DeserializeUsers(@"..\..\..\Files\Users.xml");
            foreach (var userInList in Users.List)
            {
                if (userInList.Username == username)
                    User = userInList;
            }
        }

        public void ok()
        {
            MainWindow newMainWindow = new MainWindow();
            MainWindowViewModel newMainVwMdl = new MainWindowViewModel();

            newMainWindow.DataContext = newMainVwMdl;
            App.Current.MainWindow.Close();
            App.Current.MainWindow = newMainWindow;
            newMainWindow.Show();
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged<T>(ref T property, T value, [CallerMemberName] string propertyName = "")
        {
            property = value;
            var handler = PropertyChanged;
            if (handler != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
