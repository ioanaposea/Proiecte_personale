﻿using Hangman.Models;
using Hangman.View;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Hangman.ViewModels
{
    public class PlayNewOrResumeViewModel : INotifyPropertyChanged
    {
        public ObservableCollection<Category> Categories { get; set; }
        private User _user;
        private Category _currentCategory = Category.None;
        public Category CurrentCategory
        {
            get { return _currentCategory; }
            set { OnPropertyChanged(ref _currentCategory, value); }
        }

        public PlayNewOrResumeViewModel()
        {
            Categories = new ObservableCollection<Category>();
            Categories.Add(Category.All);
            Categories.Add(Category.Cars);
            Categories.Add(Category.TvShows);
            Categories.Add(Category.Movies);
            Categories.Add(Category.Countries);
        }

        public PlayNewOrResumeViewModel(User user)
        {
            _user = user;
            Categories = new ObservableCollection<Category>();
            Categories.Add(Category.All);
            Categories.Add(Category.Cars);
            Categories.Add(Category.TvShows);
            Categories.Add(Category.Movies);
            Categories.Add(Category.Countries);
        }

        private void openGame(bool gameResumed)
        {
            HangmanGame hangmanGameWindow = new HangmanGame();
            HangmanGameViewModel hangmanGameVwMdl = new HangmanGameViewModel(_user, gameResumed);

            hangmanGameWindow.DataContext = hangmanGameVwMdl;
            App.Current.MainWindow.Close();
            App.Current.MainWindow = hangmanGameWindow;
            hangmanGameWindow.Show();
        }

        public void NewGame()
        {
            _user.GameSaved.Level = 1;
            _user.GameSaved.Mistakes = 0;
            _user.GameSaved.CategoryType = CurrentCategory;
            _user.GameSaved.WordOnDisplay = "";
            _user.GameSaved.WordToGuess = "";
            _user.GameSaved.TimeLeft = 30;
            _user.GameSaved.SavedGame = false;

            openGame(false);
        }

        public void ResumeGame()
        {
            if (_user.GameSaved.SavedGame == false)
            {
                MessageBox.Show("YOU DON'T HAVE ANY GAME SAVED", "Information");
                return;
            }

            openGame(true);
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged<T>(ref T property, T value, [CallerMemberName] string propertyName = "")
        {
            property = value;
            var handler = PropertyChanged;
            if (handler != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
