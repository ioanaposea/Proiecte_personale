﻿using Hangman.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media.Imaging;

namespace Hangman.ViewModels
{
    [Serializable]
    public class NewUserWindowViewModel : INotifyPropertyChanged
    {
        private Users users = new Users();
        private SerializationHelp serialization = new SerializationHelp();
        private string _usernameTxtBox;
        private Images Imagess = new Images();
        private BitmapImage _currentImages;

        public string UsernameTxtBox
        {
            get { return _usernameTxtBox; }
            set { OnPropertyChanged(ref _usernameTxtBox, value); }
        }

        public BitmapImage CurrentImages
        {
            get { return _currentImages; }
            set { OnPropertyChanged(ref _currentImages, value); }
        }

        public NewUserWindowViewModel()
        {
            //IconPos = 0;
            CurrentImages = Imagess.UserIcon.ElementAt(0);
        }

        public void AddUser()
        {
            if (UsernameTxtBox == null)
            {
                MessageBox.Show("No nickname inserted", "Information");
                return;
            }

            users = serialization.DeserializeUsers(@"..\..\..\Files\Users.xml");
            if (!Help.CanAddUser(UsernameTxtBox, users))
            {
                MessageBox.Show("This nickname is taken", "Information");
                return;
            }

            User user = new User { Username = UsernameTxtBox, IconPath = CurrentImages.UriSource.ToString() };
            user.GameSaved = new Game { SavedGame = false };
            user.Statistic = new Statistics();
            users.List.Add(user);
            serialization.SerializeUsers(@"..\..\..\Files\Users.xml", users);

            MainWindow newMainWindow = new MainWindow();
            MainWindowViewModel newMainVwMdl = new MainWindowViewModel();

            newMainWindow.DataContext = newMainVwMdl;
            App.Current.MainWindow.Close();
            App.Current.MainWindow = newMainWindow;
            newMainWindow.Show();
        }

        public void plusIcon()
        {
            int index = Imagess.UserIcon.IndexOf(CurrentImages);
            Debug.WriteLine(CurrentImages.UriSource);
            if (index < Imagess.UserIcon.Count - 1)
            {
                index++;
                CurrentImages = Imagess.UserIcon[index];
            }
        }

        public void minusIcon()
        {
            int index = Imagess.UserIcon.IndexOf(CurrentImages);
            if (index > 0)
            {
                index--;
                CurrentImages = Imagess.UserIcon[index];
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged<T>(ref T property, T value, [CallerMemberName] string propertyName = "")
        {
            property = value;
            var handler = PropertyChanged;
            if (handler != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
