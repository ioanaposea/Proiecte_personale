﻿using Hangman.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hangman.View
{
    /// <summary>
    /// Interaction logic for PlayNewOrResumeWindow.xaml
    /// </summary>
    public partial class PlayNewOrResumeWindow : Window
    {
        public PlayNewOrResumeWindow()
        {
            InitializeComponent();
        }


        private void newGame_click(object sender, RoutedEventArgs e)
        {
            if (category_listBox.SelectedItem != null)
                (this.DataContext as PlayNewOrResumeViewModel).NewGame();
            else
                MessageBox.Show("Please, select a category first", "Information");
        }

        private void resumeGame_click(object sender, RoutedEventArgs e)
        {
            (this.DataContext as PlayNewOrResumeViewModel).ResumeGame();
        }
    }
}
