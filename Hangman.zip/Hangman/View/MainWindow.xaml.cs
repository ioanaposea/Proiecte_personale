﻿using Hangman.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hangman
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void NewUserButton_Click(object sender, RoutedEventArgs e)
        {
            (this.DataContext as MainWindowViewModel).AddNewUser();
        }

        private void DeleteUserButton_Click(object sender, RoutedEventArgs e)
        {
            if (users_list.SelectedItem != null)
                (this.DataContext as MainWindowViewModel).DeleteUser();
            else
                MessageBox.Show("For deleting a player, you have to select one first", "Information");
        }

        private void PlayButton_Click(object sender, RoutedEventArgs e)
        {
            if (users_list.SelectedItem != null)
                (this.DataContext as MainWindowViewModel).PlayGame();
            else
                MessageBox.Show("For starting the game, you have to select a player first", "Information");
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
