﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace NotepadTema1
{
    public class Tab_ : INotifyPropertyChanged
    {
        private string _tabPath;
        private string _tabName;
        private string _tabText;
        private bool _textChanged;
        private string _initialText;
        private string _outputText;
        private FindWord _findWord = new FindWord();
        public string TabPath
        {
            get { return _tabPath; }
            set { OnPropertyChanged(ref _tabPath, value); }
        }
        public string TabName
        {
            get { return _tabName; }
            set { OnPropertyChanged(ref _tabName, value); }
        }
        public string TabText
        {
            get { return _tabText; }
            set { OnPropertyChanged(ref _tabText, value); TextChanged = true; }
        }
        public string InitialText
        {
            get { return _initialText; }
            set { OnPropertyChanged(ref _initialText, value); }
        }
        public string OutputText
        {
            get { return _outputText; }
            set { OnPropertyChanged(ref _outputText, value); }
        }
        public bool TextChanged
        {
            get
            {
                if (InitialText != TabText)
                    return true;
                return false;
            }
            set { OnPropertyChanged(ref _textChanged, value); }
        }
        public FindWord findWord
        {
            get { return _findWord; }
            set { OnPropertyChanged(ref _findWord, value); }
        }

        public Tab_(string name, string path, string text)
        {
            _tabName = name;
            _tabPath = path;
            _tabText = text;
            _initialText = text;
            _outputText = "";
        }
        public Tab_() { }
        public bool TabTextChanged
        {
            get
            {
                if (InitialText != TabText)
                    return true;
                return false;
            }
        }


        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged<T>(ref T property, T value, [CallerMemberName] string propertyName = "")
        {
            property = value;
            var handler = PropertyChanged;
            if (handler != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

}
