﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace NotepadTema1
{
    /// <summary>
    /// Interaction logic for SaveFileWindow.xaml
    /// </summary>
    public partial class SaveFileWindow : Window
    {
        public SaveFileWindow()
        {
            InitializeComponent();
        }

        private void Yes_Button(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
        }
        private void No_Button(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
