﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using Microsoft.Win32;
using System.IO;
using System.Collections.ObjectModel;

namespace NotepadTema1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            TreeViewInit();
        }

        private void NewItem_Click(object sender, RoutedEventArgs e)
        {
            (this.DataContext as TabsModel).NewItem();
        }

        private void Open_Click(object sender, RoutedEventArgs e)
        {
            (this.DataContext as TabsModel).OpenItem();
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            (this.DataContext as TabsModel).SaveItem(tab_control.SelectedIndex);
        }

        private void SaveAs_Click(object sender, RoutedEventArgs e)
        {
            (this.DataContext as TabsModel).SaveAsItem(tab_control.SelectedIndex);
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void Find_Click(object sender, RoutedEventArgs e)
        {
            (this.DataContext as TabsModel).Find(tab_control.SelectedIndex);
            //var tab = tab_control.Items[tab_control.SelectedIndex] as TabItem;
            //var tb = tab.Content as TextBox;

        }
        private void FindAll_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new FindWindow2();
            dialog.ShowDialog();
        }

        private void Replace_Click(object sender, RoutedEventArgs e)
        {
            (this.DataContext as TabsModel).ReplaceWord(tab_control.SelectedIndex);
        }

        private void About_Click(object sender, RoutedEventArgs e)
        {
            About about = new About();
            about.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            about.Show();
        }

        private void Close_Button(object sender, RoutedEventArgs e)
        {
            (this.DataContext as TabsModel).CloseItem(tab_control.SelectedIndex);
        }

        private void PrintClick(object sender, RoutedEventArgs e)
        {
            PrintDialog printDialog = new PrintDialog();
            if (printDialog.ShowDialog() == true)
            {
                printDialog.PrintVisual(tab_control, "My First Print Job");
                printDialog.PrintVisual(treeView, "My First Print Job");
            }
        }

        private void TreeViewInit()
        {
            TreeViewItem c = new TreeViewItem();
            c.Header = "C:";
            c.Expanded += new RoutedEventHandler(expandTree);
            TreeViewItem fChildC = new TreeViewItem();
            fChildC.Header = "fakeChild";
            c.Items.Add(fChildC);
            c.Tag = "C:\\";

            treeView.Items.Add(c);

            TreeViewItem d = new TreeViewItem();
            d.Header = "D:";
            d.Expanded += new RoutedEventHandler(expandTree);
            TreeViewItem fChildD = new TreeViewItem();
            fChildD.Header = "fakeChild";
            d.Items.Add(fChildD);
            d.Tag = "D:\\";

            treeView.Items.Add(d);
        }

        public void expandTree(object sender, RoutedEventArgs e)
        {
            TreeViewItem item = e.Source as TreeViewItem;

            if ((File.GetAttributes(item.Tag.ToString()) & FileAttributes.Directory) == FileAttributes.Directory)
                if ((item.Items[0] as TreeViewItem).Header.ToString() == "fakeChild")
                {
                    item.Items.Remove(item.Items[0]);

                    string[] directories = Directory.GetDirectories(item.Tag.ToString());
                    foreach (string i in directories)
                    {
                        TreeViewItem tree = new TreeViewItem();
                        tree.Header = System.IO.Path.GetFileName(i);
                        tree.Tag = i;
                        tree.Expanded += expandTree;

                        TreeViewItem fakeChild = new TreeViewItem();
                        fakeChild.Header = "fakeChild";
                        tree.Items.Add(fakeChild);
                        item.Items.Add(tree);
                    }

                    string[] files = Directory.GetFiles(item.Tag.ToString());
                    foreach (string i in files)
                    {
                        TreeViewItem tree = new TreeViewItem();
                        tree.Header = System.IO.Path.GetFileName(i);
                        tree.Tag = i;
                        tree.MouseDoubleClick += TreeView_MouseClick;
                        item.Items.Add(tree);
                    }
                }
        }

        private void TreeView_MouseClick(object sender, MouseButtonEventArgs e)
        {
            TreeViewItem s = sender as TreeViewItem;
            (this.DataContext as TabsModel).treeViewOpen(s);
        }

        //private void IterateSubdirectories(TreeViewItem item, string path)
        //{
        //    string[] directories = Directory.GetDirectories(path);
        //    foreach (string directory in directories)
        //    {
        //        TreeViewItem folder = new TreeViewItem();
        //        folder.Header = System.IO.Path.GetFileName(directory);
        //        IterateSubdirectories(folder, directory);
        //        string[] files = Directory.GetFiles(directory);
        //        foreach (string file in files)
        //        {
        //            TreeViewItem currentFile = new TreeViewItem();
        //            currentFile.Header = System.IO.Path.GetFileName(file);
        //            currentFile.Tag = file;
        //            currentFile.MouseDoubleClick += TreeView_MouseClick;
        //            folder.Items.Add(currentFile);
        //        }
        //        item.Items.Add(folder);
        //    }
        //}
    }
}
