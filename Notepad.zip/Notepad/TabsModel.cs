﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace NotepadTema1
{
    class TabsModel : INotifyPropertyChanged
    {
        private Tab_ _currentTab = new Tab_();
        public Tab_ CurrentTab
        {
            get { return _currentTab; }
            set { OnPropertyChanged(ref _currentTab, value); }
        }

        private ObservableCollection<Tab_> _items = new ObservableCollection<Tab_>();
        public ObservableCollection<Tab_> Items
        {
            get { return _items; }
            set { OnPropertyChanged(ref _items, value); }
        }

        public void NewItem()
        {
            Tab_ tab_ = new Tab_("New " + Items.Count(), "", "");
            Items.Add(tab_);
            CurrentTab = tab_;
        }

        public void CloseItem(int position)
        {
            if (position >= 0 && position <= Items.Count)
            {
                CurrentTab = Items[position];

                if (CurrentTab.TabTextChanged == true)
                    if (CurrentTab.TabPath == "")
                    {
                        var dialog = new SaveFileWindow();
                        dialog.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                        bool? result = dialog.ShowDialog();

                        if (result == true)
                            SaveAsItem(position);
                    }
                    else
                    {
                        var dialog = new SaveWindow();
                        dialog.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                        bool? result = dialog.ShowDialog();

                        if (result == true)
                            SaveItem(position);
                    }

                Items.Remove(CurrentTab);
            }
        }

        public void OpenItem()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            Tab_ tab_;
            if (openFileDialog.ShowDialog() == true)
            {
                tab_ = new Tab_(System.IO.Path.GetFileName(openFileDialog.FileName), System.IO.Path.GetFullPath(openFileDialog.FileName), File.ReadAllText(openFileDialog.FileName));
                Items.Add(tab_);
                CurrentTab = tab_;
            }

        }

        public void SaveItem(int position)
        {
            if (position >= 0 && position <= Items.Count)
            {
                CurrentTab = Items[position];

                if (CurrentTab.TabPath != "")
                    if (CurrentTab.TabTextChanged == true)
                    {
                        File.WriteAllText(CurrentTab.TabPath, CurrentTab.TabText);
                        CurrentTab.InitialText = CurrentTab.TabText;
                        CurrentTab.TextChanged = false;
                    }
            }
        }

        public void SaveAsItem(int position)
        {
            if (position >= 0 && position <= Items.Count)
            {
                CurrentTab = Items[position];

                if (CurrentTab.TabPath == "")
                {
                    SaveFileDialog saveFileDialog = new SaveFileDialog();
                    saveFileDialog.Filter = "Text file (*.txt)|*.txt|All files (*.*)|*.*";

                    if (saveFileDialog.ShowDialog() == true)
                    {
                        File.WriteAllText(saveFileDialog.FileName, CurrentTab.TabText);
                        CurrentTab.InitialText = CurrentTab.TabText;
                        CurrentTab.TabName = System.IO.Path.GetFileName(saveFileDialog.FileName);
                        CurrentTab.TabPath = System.IO.Path.GetFullPath(saveFileDialog.FileName);
                        CurrentTab.TextChanged = false;
                    }
                }
            }
        }

        public void writeOutputText(Tab_ t, string word)
        {
            t.findWord.clearFindWord();
            t.findWord.Word = word;
            t.findWord.doPositions(t.findWord.Word, t.TabText);
            t.OutputText = word;
            t.OutputText = t.OutputText.Insert(t.OutputText.Length, Environment.NewLine);
            foreach (int i in t.findWord.Positions)
            {
                t.OutputText = t.OutputText.Insert(t.OutputText.Length, i.ToString());
                t.OutputText = t.OutputText.Insert(t.OutputText.Length, " ");
            }
        }

        public void Find(int position)
        {
            if (position >= 0 && position <= Items.Count)
            {
                CurrentTab = Items[position];

                var dialog = new FindWindow();
                if (dialog.ShowDialog() == true)
                {
                    string word = dialog.getWord;
                    string mode = dialog.getCombo; //ComboBox

                    if (mode == "In current tab")
                    {
                        writeOutputText(CurrentTab, word);
                    }
                    else //if (mode == "In all tabs")
                    {
                        foreach (Tab_ i in Items)
                            writeOutputText(i, word);
                    }
                }
            }

        }

        public void ReplaceWord(int position)
        {
            if (position >= 0 && position <= Items.Count)
            {
                CurrentTab = Items[position];

                var dialog = new ReplaceWindow();
                if (dialog.ShowDialog() == true)
                {
                    string wordSearch = dialog.getWordSearch;
                    string wordReplace = dialog.getWordReplace;
                    string mode = dialog.getCombo; //ComboBox

                    if (mode == "Replace")
                    {
                        if (CurrentTab.TabText.Contains(wordSearch) == true)
                        {
                            int index = CurrentTab.TabText.IndexOf(wordSearch);
                            if (index >= 0)
                            {
                                CurrentTab.TabText = CurrentTab.TabText.Remove(index, wordSearch.Length);
                                CurrentTab.TabText = CurrentTab.TabText.Insert(index, wordReplace);
                            }
                        }
                    }

                    if (mode == "Replace all in current tab")
                    {
                        CurrentTab.TabText = CurrentTab.TabText.Replace(wordSearch, wordReplace);
                    }

                    if (mode == "Replace all in all tabs")
                    {
                        foreach (Tab_ i in Items)
                        {
                            i.TabText = i.TabText.Replace(wordSearch, wordReplace);
                        }
                    }
                }
            }
        }

        public void treeViewOpen(TreeViewItem s)
        {
            Tab_ tab_;
            tab_ = new Tab_(System.IO.Path.GetFileName(s.Tag.ToString()), s.Tag.ToString(), File.ReadAllText(s.Tag.ToString()));
            Items.Add(tab_);
            CurrentTab = tab_;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged<T>(ref T property, T value, [CallerMemberName] string propertyName = "")
        {
            property = value;
            var handler = PropertyChanged;
            if (handler != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
