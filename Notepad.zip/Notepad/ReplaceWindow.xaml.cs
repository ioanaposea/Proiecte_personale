﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace NotepadTema1
{
    /// <summary>
    /// Interaction logic for ReplaceWindow.xaml
    /// </summary>
    public partial class ReplaceWindow : Window
    {
        public ReplaceWindow()
        {
            InitializeComponent();
        }
        public string getWordSearch
        {
            get { return textBox.Text; }
        }
        public string getWordReplace
        {
            get { return textBox2.Text; }
        }
        public string getCombo
        {
            get { return comboBox.Text; }
        }

        private void ReplaceButton(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
        }
       
    }
}
