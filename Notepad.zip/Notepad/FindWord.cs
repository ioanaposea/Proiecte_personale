﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace NotepadTema1
{
    public class FindWord : INotifyPropertyChanged
    {
        private string _word;
        private List<int> _positions = new List<int>();
        private int _currentPosition;

        public string Word
        {
            get { return _word; }
            set { OnPropertyChanged(ref _word, value); }
        }
        public List<int> Positions
        {
            get { return _positions; }
            set { OnPropertyChanged(ref _positions, value); }
        }
        public int CurrentPosition
        {
            get { return _currentPosition; }
            set { OnPropertyChanged(ref _currentPosition, value); }
        }

        public void doPositions(string word, string text)
        {
            _word = word;

            if (text.Substring(0).Contains(word) == true)
            {
                int index = text.IndexOf(word, 0);

                do
                {
                    //Console.WriteLine(index);
                    Positions.Add(index);
                    index += word.Length;

                    if (text.Substring(index).Contains(word) == true)
                    {
                        index = text.IndexOf(word, index);
                    }
                } while (text.Substring(index).Contains(word) == true);
            }
        }

        public void clearFindWord()
        {
            _word = "";
            _currentPosition = 0;
            _positions.Clear();
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged<T>(ref T property, T value, [CallerMemberName] string propertyName = "")
        {
            property = value;
            var handler = PropertyChanged;
            if (handler != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
