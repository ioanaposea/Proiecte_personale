﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace NotepadTema1
{
    /// <summary>
    /// Interaction logic for FindWindow2.xaml
    /// </summary>
    public partial class FindWindow2 : Window
    {
        public FindWindow2()
        {
            InitializeComponent();
        }

        FindWord f = new FindWord();

        public void notFound()
        {
            string message = "The word could not be found";
            string title = "Information";
            MessageBox.Show(message, title);
        }

        public void insertWordFirst()
        {
            string message = "Please insert a word first";
            string title = "Information";
            MessageBox.Show(message, title);
        }

        private void find_button(object sender, RoutedEventArgs e)
        {
            string text = textBox.Text;
            string word = findWordTextBox.Text;

            if (word != "")
            {
                f.clearFindWord();
                f.doPositions(word, text);

                if (f.Positions.Count != 0)
                {
                    textBox.Focus();
                    textBox.SelectionBrush = Brushes.Red;
                    textBox.Select(f.Positions[f.CurrentPosition], findWordTextBox.Text.Length);
                }
                else
                    notFound();
            }
            else
                insertWordFirst();
        }

        private void find_buttonNext(object sender, RoutedEventArgs e)
        {
            if (findWordTextBox.Text == f.Word)
            {
                if (f.Positions.Count != 0)
                {
                    if (f.CurrentPosition < f.Positions.Count - 1)
                        f.CurrentPosition++;
                    textBox.Focus();
                    textBox.SelectionBrush = Brushes.Red;
                    textBox.Select(f.Positions[f.CurrentPosition], findWordTextBox.Text.Length);
                }
                else
                    notFound();
            }
            else
                insertWordFirst();
        }

        private void find_buttonPrevious(object sender, RoutedEventArgs e)
        {
            if (findWordTextBox.Text == f.Word)
            {
                if (f.Positions.Count != 0)
                {
                    if (f.CurrentPosition > 0)
                        f.CurrentPosition--;
                    textBox.Focus();
                    textBox.SelectionBrush = Brushes.Red;
                    textBox.Select(f.Positions[f.CurrentPosition], findWordTextBox.Text.Length);
                }
                else
                    notFound();
            }
            else
                insertWordFirst();
        }
    }
}
