#include "Graf.h"

void Graf::GenerareListaAdiacenta()
{
    std::vector<Node> row;
    for(int i=0;i<getNumberofNodes();i++)
        listaAdiacenta.push_back(row);

    for(int i=0;i<getNumberofNodes();i++)
    {
        for(int j=0;j<getNumberofNodes();j++)
        {
            for(int k=0;k<arce.size();k++)
            {
                if(arce[k].getFirstPoint().getNumber()==i && arce[k].getSecondPoint().getNumber()==j)
                    listaAdiacenta[arce[k].getFirstPoint().getNumber()].push_back(arce[k].getSecondPoint());
            }
        }
    }
}

std::vector<Arc> Graf::GetArce()
{
    return arce;
}

std::vector<Node> Graf::GetNoduri()
{
    return noduri;
}

void Graf::AddNod(Node n)
{
    n.setNumber(noduri.size());//a dat numarul nodului
    noduri.push_back(n);
}

void Graf::AddArc(Arc n)
{
    for(int i=0;i<arce.size();i++)
        if(arce[i].getFirstPoint().getNumber()==n.getFirstPoint().getNumber() && arce[i].getSecondPoint().getNumber()==n.getSecondPoint().getNumber())
            return;
    arce.push_back(n);
}

Node Graf::GetLastNode()
{
    return noduri[noduri.size()-1];
}

int Graf::getNumberofNodes()
{
    return noduri.size();
}

void Graf::DFS(int x, std::vector<int> &visited)
{
    visited[x] = true;
    for (auto y : GetArce())
    {
        if (y.getFirstPoint().getNumber() == x)
        {
            if (!visited[y.getSecondPoint().getNumber()])
                DFS(y.getSecondPoint().getNumber(), visited);
        }
    }
}

int Graf::findRoot()
{
    if(noduri.empty())
        return -1;
    GenerareListaAdiacenta();

    std::vector<int> visited;
    int V;
    V = -1;

    for (int i=0;i<noduri.size();i++)
        visited.push_back(0);

    for (auto& nod : noduri)
    {
        if (!visited[nod.getNumber()])
        {
            DFS(nod.getNumber(), visited);
            V = nod.getNumber();
        }
    }

    visited.clear();
    for (int i=0;i<noduri.size();i++)
        visited.push_back(0);

    DFS(V, visited);

    for (auto& nod : noduri)
    {
        if (!visited[nod.getNumber()])
            V= -1;
    }

    return V;
}
