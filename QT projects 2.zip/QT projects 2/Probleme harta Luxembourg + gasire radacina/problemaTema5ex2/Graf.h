#ifndef GRAF_H
#define GRAF_H
#include "Node.h"
#include "Arc.h"
#include <QtXml>
#include <QDebug>
#include <QTextStream>
#include<vector>
#include<iostream>
#include<queue>

class Graf
{
    std::vector<Node> noduri;
    std::vector<Arc> arce;
    //std::vector<std::vector<int>> matriceAdiacenta;
    std::vector<std::vector<int>> matriceLungimi;
    std::vector<std::vector<Node>> listaAdiacenta;
public:
    //void GenerareMatriceAdiacenta();
    void GenerareListaAdiacenta();
    void GenerareMatriceLungimi();
    std::vector<Arc> GetArce();
    std::vector<Node> GetNoduri();
    void AddNod(Node n);
    void AddArc(Arc a);
    void DrawGraf(QPainter *p);
    Node GetLastNode();
    int getNumberofNodes();
    Node searchNode(int valueOfNode);
    bool readFile();
    void listElements(QDomElement root, bool type, QString tagname, QString attribute, QString attribute2, QString attribute3);
    std::vector<int> Dijkstra(int start, int stop);
};
#endif // GRAF_H
