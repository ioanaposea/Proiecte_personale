#include "Arc.h"

Arc::Arc(Node n1, Node n2, int len)
{
    firstNode = n1;
    secondNode = n2;
    length = len;
}

Node Arc::getFirstPoint()
{
    return firstNode;
}
Node Arc::getSecondPoint()
{
    return secondNode;
}

int Arc::getLength()
{
    return length;
}
