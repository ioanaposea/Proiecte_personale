#include "Graf.h"
#include<iostream>

void Graf::GenerareListaAdiacenta()
{
    std::vector<Node> row;
    for(int i=0;i<getNumberofNodes();i++)
        listaAdiacenta.push_back(row);
}

void Graf::GenerareMatriceLungimi()
{
    std::vector<int> row;
    for(int i=0;i<getNumberofNodes();i++)
        row.push_back(-1);
    for(int i=0;i<getNumberofNodes();i++)
        matriceLungimi.push_back(row);
}

std::vector<Arc> Graf::GetArce()
{
    return arce;
}

std::vector<Node> Graf::GetNoduri()
{
    return noduri;
}

void Graf::AddNod(Node n)
{
    n.setNumber(noduri.size());
    noduri.push_back(n);
}

void Graf::AddArc(Arc n)
{
    for(int i=0;i<arce.size();i++)
        if(arce[i].getFirstPoint().getNumber()==n.getFirstPoint().getNumber() && arce[i].getSecondPoint().getNumber()==n.getSecondPoint().getNumber())
            return;
    arce.push_back(n);
}

Node Graf::GetLastNode()
{
    return noduri[noduri.size()-1];
}

int Graf::getNumberofNodes()
{
    return noduri.size();
}

Node Graf::searchNode(int valueOfNode)
{
    Node x;
    for(auto& it: noduri)
    {
        if(valueOfNode == it.getNumber())
        {
            x=it;
            return x;
        }
    }
    return x;
}

void Graf::listElements(QDomElement root, bool type, QString tagname, QString attribute, QString attribute2, QString attribute3)
{
    QDomNodeList items = root.elementsByTagName(tagname);
    qDebug() << "Total read items = "<<items.count();

    if(type == true) //true = nod
    {
        int lngmin = INT_MAX, lngmax = INT_MIN, latmin = INT_MAX, latmax = INT_MIN;
        int lng, lat;

        int size=items.size();
        for(int i=0;i<size;i++)
        {
            QDomNode itemnode = items.at(i);

            if(itemnode.isElement())
            {
                QDomElement itemele = itemnode.toElement();
                lng = itemele.attribute(attribute2).toUInt();
                lat = itemele.attribute(attribute3).toUInt();

                if(lng > lngmax)
                    lngmax = lng;
                if(lng < lngmin)
                    lngmin = lng;
                if(lat > latmax)
                    latmax = lat;
                if(lat < latmin)
                    latmin = lat;
            }
        }
        qDebug()<<lngmax<<" "<<lngmin<<" "<<latmax<<" "<<latmin;

        float xcoord, ycoord;
        float l1=lngmax-lngmin,l2=latmax-latmin;
        for(int i=0;i<size;i++)
        {
            QDomNode itemnode = items.at(i);

            if(itemnode.isElement())
            {
                QDomElement itemele = itemnode.toElement();
                lng = itemele.attribute(attribute2).toUInt();
                lat = itemele.attribute(attribute3).toUInt();

                float ll1=lng-lngmin,ll2=latmax-lat;
                xcoord=(1850/l1)*ll1;
                ycoord=(950/l2)*ll2;

                QPoint p(xcoord,ycoord);
                AddNod(p);
            }
        }
    }
    else //false = arc
    {
        int from, to, len;
        int size=items.size();
        for(int i=0;i<size;i++)
        {
            QDomNode itemnode = items.at(i);

            if(itemnode.isElement())
            {
                QDomElement itemele = itemnode.toElement();
                from = itemele.attribute(attribute).toUInt();
                to = itemele.attribute(attribute2).toUInt();
                len = itemele.attribute(attribute3).toUInt();
                Node x,y;

                Arc arcAux(searchNode(from), searchNode(to), len);
                AddArc(arcAux);

                listaAdiacenta[arcAux.getFirstPoint().getNumber()].push_back(arcAux.getSecondPoint());
                listaAdiacenta[arcAux.getSecondPoint().getNumber()].push_back(arcAux.getFirstPoint());
                matriceLungimi[arcAux.getFirstPoint().getNumber()][arcAux.getSecondPoint().getNumber()] = arcAux.getLength();

                qDebug()<<from<<" "<<to;
            }
        }
    }
    qDebug()<<"Finished";
}

bool Graf::readFile()
{

    QDomDocument document;
    QFile file("C:/Users/ioana/Desktop/ioana/cursuri/Algoritmica grafurilor/Laborator/tema 5/Harta_Luxemburg.xml");
    if(!file.open(QIODevice::ReadOnly|QIODevice::Text))
    {
        qDebug()<<"Failed to open file";
        return false;
    }
    else
    {
        if(!document.setContent(&file))
        {
            qDebug()<<"Failed to load document";
            return false;
        }

        file.close();
    }

    QDomElement root = document.firstChildElement();
    listElements(root, true, "node", "id","longitude","latitude");

    GenerareListaAdiacenta();
    GenerareMatriceLungimi();

    listElements(root, false, "arc", "from","to","length");

    return true;
}

std::vector<int> Graf::Dijkstra(int start, int stop)
{
    std::vector<int> W,d,p;
    std::vector<bool> S;
    std::priority_queue<std::pair<int,int>> Q;
    int x;

    for(int i=0;i<getNumberofNodes();i++)
    {
        d.push_back(INFINITY);
        p.push_back(0);
        W.push_back(i);
        S.push_back(false);
    }

    d[start]=0;
    Q.push(std::make_pair(start,0));

    while(!Q.empty())
    {
        x=Q.top().first;
        Q.pop();

        if(S[x])
            continue;
        if(x==stop)
            break;

        S[x]=true;

        for(auto& y:listaAdiacenta[x])
        {
            //y este nod
            //std::vector<int>::iterator it = std::find(W.begin(), W.end(), y.getNumber());

            if(!S[y.getNumber()])
            {

                if(d[y.getNumber()]> d[x] + matriceLungimi[x][y.getNumber()])
                {
                    d[y.getNumber()] = d[x] + matriceLungimi[x][y.getNumber()];
                    p[y.getNumber()] = x;
                    Q.push(std::make_pair(y.getNumber(),d[y.getNumber()]));
                }
            }
        }
    }

    return p;
}
