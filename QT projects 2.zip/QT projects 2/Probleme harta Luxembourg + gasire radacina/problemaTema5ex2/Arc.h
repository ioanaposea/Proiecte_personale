#ifndef ARC_H
#define ARC_H

#include "Node.h"
class Arc
{
    Node firstNode, secondNode;
    int length;
public:
    Arc(Node n1, Node n2, int len);
    Node getFirstPoint();
    Node getSecondPoint();
    int getLength();
};
#endif // ARC_H
