#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "Node.h"
#include <QMouseEvent>
#include <QPainter>
#include <QFile>
#include<QTextStream>
#include <QRadioButton>
#include<QMessageBox>
#include<QPainter>
#include<QtMath>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    button = false;
    chooseWay = false;
    ui->setupUi(this);
}

void MainWindow::mouseReleaseEvent(QMouseEvent *e)
{
    if(e->button() == Qt::LeftButton)
    {
        QPointF p = e->localPos();
        std::vector<Node> noduri = g.GetNoduri();
        Node foundNode;
        for (auto& n : noduri)
        {
            if (fabs(n.getPoint().x() - p.x()) < 20 && fabs(n.getPoint().y() - p.y()) < 20)
            {
                foundNode = n;
                break;
            }
        }
        if (foundNode.getNumber() == -1)
            return;
        if (firstNode.getNumber() == -1)
        {
            firstNode = foundNode;
        }
        else
        {
            if(foundNode.getNumber()!=firstNode.getNumber())
                secondNode = foundNode;

            firstN=firstNode;
            secondN=secondNode;

            qDebug()<<firstN.getNumber()<<" "<<secondN.getNumber();

            pa.clear();
            pa = g.Dijkstra(firstN.getNumber(),secondN.getNumber());

            qDebug()<<"Dijkstra efectuat!";

            //for(int i=0;i<pa.size();i++)
                //qDebug()<<pa[i]<<" ";

            firstNode = Node();
            secondNode = Node();

            chooseWay = true;
            update();
        }
    }
}


void MainWindow::paintEvent(QPaintEvent *event)
{
    QPainter p(this);
    if(button == true)
    {
        if (g.getNumberofNodes())
        {
            std::vector<Arc> arce = g.GetArce();
            for(auto& arc: arce)
            {
                p.drawLine(arc.getFirstPoint().getPoint(), arc.getSecondPoint().getPoint());
            }

            if(chooseWay)
            {
                p.setPen(QPen(Qt::magenta));
                p.setBrush(Qt::magenta);
                QRect r(firstN.getPoint().x()-10,firstN.getPoint().y()-10, 20,20);
                p.drawEllipse(r);
                QRect r1(secondN.getPoint().x()-10,secondN.getPoint().y()-10, 20,20);
                p.drawEllipse(r1);

                int i=secondN.getNumber();
                while(i!=firstN.getNumber())
                {
                    std::vector<Arc> arce = g.GetArce();
                    for(auto& j:arce)
                    {
                        if(j.getFirstPoint().getNumber()==pa[i] && j.getSecondPoint().getNumber()==i)
                            p.drawLine(j.getFirstPoint().getPoint(), j.getSecondPoint().getPoint());
                        if(j.getFirstPoint().getNumber()==i && j.getSecondPoint().getNumber()==pa[i])
                            p.drawLine(j.getFirstPoint().getPoint(), j.getSecondPoint().getPoint());
                    }

                    i=pa[i];
                }

                qDebug()<<"Afisare gata";

            }
        }
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_SaveGraf_released()
{

}

void MainWindow::on_pushButton_clicked()
{
    if(g.readFile())
    {
        QMessageBox::information(this, "Stare citire", "Fisierul a fost citit");

        button = true;
        update();
    }
    else
        QMessageBox::information(this, "Stare citire", "Fisierul NU a putut fi citit");
}

