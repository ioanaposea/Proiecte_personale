#include "Graf.h"
#include<iostream>
#include<QFile>
#include<QTextStream>

void Graf::GenerareListaAdiacenta()
{
    std::vector<Node> row;
    for(int i=0;i<getNumberofNodes();i++)
        listaAdiacenta.push_back(row);

    for(int i=0;i<getNumberofNodes();i++)
    {
        for(int j=0;j<getNumberofNodes();j++)
        {
             for(int k=0;k<arce.size();k++)
             {
                 if(arce[k].getFirstPoint().getNumber()==i && arce[k].getSecondPoint().getNumber()==j)
                     listaAdiacenta[arce[k].getFirstPoint().getNumber()].push_back(arce[k].getSecondPoint());
             }
        }
    }
}

std::vector<Arc> Graf::GetArce()
{
    return arce;
}

std::vector<Node> Graf::GetNoduri()
{
    return noduri;
}

void Graf::AddNod(Node n)
{
    n.setNumber(noduri.size());
    noduri.push_back(n);
}

void Graf::AddArc(Arc n)
{
    for(int i=0;i<arce.size();i++)
        if(arce[i].getFirstPoint().getNumber()==n.getFirstPoint().getNumber() && arce[i].getSecondPoint().getNumber()==n.getSecondPoint().getNumber())
            return;
    arce.push_back(n);
}

Node Graf::GetLastNode()
{
    return noduri[noduri.size()-1];
}

int Graf::getNumberofNodes()
{
    return noduri.size();
}

bool Graf::verifCicluri(int v, std::vector<bool> &visited, std::vector<bool> &stiva)
{
    if (visited[v] == false)
    {
        visited[v] = true;
        stiva[v] = true;

        std::vector<Node>::iterator i;
        for (i = listaAdiacenta[v].begin(); i != listaAdiacenta[v].end(); ++i)
        {
            if (!visited[i->getNumber()] && verifCicluri(i->getNumber(), visited, stiva))
                return true;
            else if (stiva[i->getNumber()])
                return true;
        }
    }
    stiva[v] = false;
    return false;
}

bool Graf::cicluri()
{
    std::vector<bool> visited;
    std::vector<bool> stiva;
    for (int i = 0; i < getNumberofNodes(); i++)
    {
        visited.push_back(false);
        stiva.push_back(false);
    }

    for (int i = 0; i < getNumberofNodes(); i++)
        if (verifCicluri(i, visited, stiva))
            return true;
    return false;
}

void Graf::dfs(int v, std::vector<bool> &visited, std::stack<int> &stiva)
{
    visited[v] = true;

    std::vector<Node>::iterator i;
    for (i = listaAdiacenta[v].begin(); i != listaAdiacenta[v].end(); ++i)
        if (!visited[i->getNumber()])
            dfs(i->getNumber(), visited, stiva);

    stiva.push(v);
}

void Graf::sortareTopologica()
{
    QString filename = "SortareTopologica.txt";
    QFile file(filename);
    file.open(QIODevice::WriteOnly);
    QTextStream out(&file);

    std::stack<int> stiva;
    std::vector<bool> visited;
    for (int i = 0; i < getNumberofNodes(); i++)
        visited.push_back(false);

    for (int i = 0; i < getNumberofNodes(); i++)
        if (visited[i] == false)
            dfs(i, visited, stiva);

    while (stiva.empty() == false)
    {
       out << stiva.top() << " ";
       for(auto& i:noduri)
           if(i.getNumber()==stiva.top())
               sortareTop.push_back(i);
       stiva.pop();
    }
    file.close();
}

 std::vector<Node> Graf::getVectorSort()
 {
    return sortareTop;
 }
