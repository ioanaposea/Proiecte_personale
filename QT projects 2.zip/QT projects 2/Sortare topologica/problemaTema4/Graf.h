#ifndef GRAF_H
#define GRAF_H
#include "Node.h"
#include "Arc.h"
#include<stack>

class Graf
{
    std::vector<Node> noduri;
    std::vector<Arc> arce;
    //std::vector<std::vector<int>> matriceAdiacenta;
    std::vector<std::vector<Node>> listaAdiacenta;
    std::vector<Node> sortareTop;
public:
    //void GenerareMatriceAdiacenta();
    void GenerareListaAdiacenta();
    std::vector<Arc> GetArce();
    std::vector<Node> GetNoduri();
    void AddNod(Node n);
    void AddArc(Arc a);
    void DrawGraf(QPainter *p);
    Node GetLastNode();
    int getNumberofNodes();
    bool verifCicluri(int v, std::vector<bool>& visited, std::vector<bool>& stiva);
    bool cicluri();
    void dfs(int v, std::vector<bool>& visited, std::stack<int>& stiva);
    void sortareTopologica();
    std::vector<Node> getVectorSort();
};
#endif // GRAF_H
