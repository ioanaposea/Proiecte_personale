#ifndef GRAF_H
#define GRAF_H
#include "Node.h"
#include "Arc.h"
#include<QTextStream>
#include<QFile>
#include<QVector>

class Graf
{
    std::vector<Node> noduri;
    std::vector<Arc> arce;
    std::vector<std::vector<int>> matriceAdiacenta;
    //std::vector<std::vector<int>> listaAdiacenta;
    QVector<QVector<int>>matrix;
    QVector<QVector<int>>matrixDrumuri;
    std::vector<Node> exitNodes;
    Node start;
public:
    void GenerareMatriceAdiacenta();
    //void GenerareListaAdiacenta();
    void AddExitNode(Node n);
    std::vector<Node> GetExitNodes();
    void SetStart(Node n);
    Node GetStart();
    void SetMatrix(QVector<QVector<int>>matrixAux);
    QVector<QVector<int>> GetMatrix();
    std::vector<Arc> GetArce();
    std::vector<Node> GetNoduri();
    void AddNod(Node n);
    void AddArc(Arc a);
    void DrawGraf(QPainter *p);
    Node GetLastNode();
    int getNumberofNodes();//returneaza cate noduri sunt salvate in vectorul de noduri
    void read(QFile& f,QVector<QVector<int>>& matrix);
    void PBF();
    void createMatrixDrumuri();
    QVector<QVector<int>> GetMatrixDrumuri();
};
#endif // GRAF_H
