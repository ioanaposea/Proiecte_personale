#include "Graf.h"
#include<fstream>
#include<iostream>
#include<vector>
#include<list>
#include<queue>

/*void Graf::GenerareListaAdiacenta()
{
    //lista de adiacenta e de tip int si salveaza doar numarul nodului
    listaAdiacenta.reserve(noduri.size());
    std::vector<int> row;
    for(int i=0;i<noduri.size();i++)
    {
        row.reserve(noduri.size());
        listaAdiacenta.push_back(row);
    }
    for(auto& arc: arce)
    {
        int i,j;
        i=arc.getFirstPoint().getNumber();
        j=arc.getSecondPoint().getNumber();
        listaAdiacenta[i].push_back(j);
    }
}*/

void Graf::GenerareMatriceAdiacenta()
{
    std::vector<int> row;
    for (int i = 0; i < getNumberofNodes(); i++)
    {
        row.clear();
        for (int j = 0; j < getNumberofNodes(); j++)
        {
            row.push_back(0);
        }
        matriceAdiacenta.push_back(row);
    }

    for(auto& arc:arce)
    {
        int i,j;
        i=arc.getFirstPoint().getNumber();
        j=arc.getSecondPoint().getNumber();
        matriceAdiacenta[i][j]=1;
        matriceAdiacenta[j][i]=1;
    }

}

void Graf::AddExitNode(Node n)
{
    exitNodes.push_back(n);
}

std::vector<Node> Graf::GetExitNodes()
{
    return exitNodes;
}

void Graf::SetStart(Node n)
{
    start=n;
}

Node Graf::GetStart()
{
    return start;
}

void Graf::SetMatrix(QVector<QVector<int>> matrixAux)
{
    matrix=matrixAux;
}

std::vector<Arc> Graf::GetArce()
{
    return arce;
}

std::vector<Node> Graf::GetNoduri()
{
    return noduri;
}

void Graf::AddNod(Node n)
{
    n.setNumber(noduri.size());//a dat numarul nodului
    noduri.push_back(n);
}

void Graf::AddArc(Arc n)
{
    //nu se suprapun arcele
    for(int i=0;i<arce.size();i++)
        if(arce[i].getFirstPoint().getNumber()==n.getFirstPoint().getNumber() && arce[i].getSecondPoint().getNumber()==n.getSecondPoint().getNumber())
            return;
    arce.push_back(n);
}

Node Graf::GetLastNode()
{
    return noduri[noduri.size()-1];
}

int Graf::getNumberofNodes()
{
    return noduri.size();
}

QVector<QVector<int>> Graf::GetMatrix()
{
    return matrix;
}

void Graf::read(QFile& f,QVector<QVector<int>>&matrix)
{
    QString matrixStrSize;
    QTextStream in(&f);
    in >> matrixStrSize;
    int matSize = matrixStrSize.toInt();
    while (!in.atEnd())
    {
        QString line = in.readLine();
        if(!line.isEmpty())
        {
            QStringList numsStr = line.split(" ");
            QVector<int> temp;
            for(int i(0); i < matSize; ++i)
            {
                temp.push_back(numsStr[i].toInt());
            }
            matrix.push_back(temp);
        }
    }
}

void Graf::PBF()
{
    GenerareMatriceAdiacenta();
    std::queue<int> V;
    std::vector<int> U,W,p,l;
    int s;
    s=start.getNumber();
    for(int i=0;i<getNumberofNodes();i++)
        if(i!=s)
            U.push_back(i);
    V.push(s);
    p.resize(getNumberofNodes(),-1);
    for(int i=0;i<getNumberofNodes();i++)
        if(i!=s)
            l.push_back(-1);
        else
            l.push_back(0);
    while(!V.empty())
    {
        int x;
        std::vector<int>::iterator it;
        x=V.front();
        for(int y=0;y<getNumberofNodes();y++)
        {
            if(matriceAdiacenta[x][y]==1)
            {
                it = std::find (U.begin(), U.end(), y);
                if (it != U.end())
                {
                    U.erase(it);
                    V.push(y);
                    p[y]=x;
                    l[y]=l[x]+1;
                }
            }
        }
        V.pop();
        W.push_back(x);
    }

    for(auto& nod: exitNodes)
    {
        s = nod.getNumber();
        int ok;
        ok=0;
        while(ok==0)
        {
            s=p[s];
            for(auto& nod2: noduri)
            {
                if(s==nod2.getNumber())
                {
                    nod2.SetColor("green");
                    break;
                }
            }
            if(s==start.getNumber())
            {
                ok=1;
                for(auto& nod2: noduri)
                {
                    if(s==nod2.getNumber())
                    {
                        nod2.SetColor("blue");
                        break;
                    }
                }
            }
        }
    }

    for(auto& nod: exitNodes)
    {
        for(auto& nod2: noduri)
        {
            if(nod.getNumber()==nod2.getNumber())
                nod2.SetColor("red");
        }
    }
}

void Graf::createMatrixDrumuri()
{
    int fr;
    fr=0;

    for(int i=0;i<matrix.size();i++)
    {
        QVector<int> row;
        for(int j=0;j<matrix[i].size();j++)
        {
            if(matrix[i][j]==0)
                row.push_back(-1);
            else
            {
                row.push_back(fr);
                fr++;
            }
        }
        matrixDrumuri.push_back(row);
    }
}
QVector<QVector<int>> Graf::GetMatrixDrumuri()
{
    return matrixDrumuri;
}
