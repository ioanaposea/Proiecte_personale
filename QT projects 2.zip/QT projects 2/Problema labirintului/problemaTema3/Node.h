#ifndef NODE_H
#define NODE_H

#include <QPainter>
#include<iostream>
#include<string>

class Node
{
    QPoint point;//are coord lui x si coord lui y
    int number;
    std::string color;

public:
    Node(){ number = -1; color="black"; };
    Node(QPoint p){
        point = p;
    }
    QPoint getPoint() {
        return point;
    }
    int getNumber() {
        return number;
    }
    void setNumber(int number) {
        this->number = number;
    }
    void SetColor(std::string col)
    {
        color = col;
    }
    std::string GetColor()
    {
        return color;
    }
};

#endif // NODE_H
