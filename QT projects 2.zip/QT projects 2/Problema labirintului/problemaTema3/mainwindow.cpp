#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "Node.h"
#include <QMouseEvent>
#include <QPainter>
#include <QFile>
#include<QTextStream>
#include <QRadioButton>
#include<QMessageBox>
#include<QPainter>
#include<QtMath>
#include<QDebug>
#include<iostream>
#include<QVector>
#include<string>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    drawNode = false;
    drawArc = false;
    button=false;
    button2=false;
    button3=false;
    ui->setupUi(this);
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    if (button==true)
    {
        QPainter p(this);
        std::vector<Node> noduri = g.GetNoduri();
        for(auto& nod: noduri)
        {
            std::string col=nod.GetColor();
            if(col=="black")
                p.setPen(QPen(Qt::black));
            if(col=="white")
                p.setPen(QPen(Qt::black));
            if(col=="red")
                p.setPen(QPen(Qt::red));
            if(col=="blue")
                p.setPen(QPen(Qt::blue));
            QRect r(nod.getPoint().x()-10,nod.getPoint().y()-10, 20,20);
            p.drawEllipse(r);
            p.drawText(r,Qt ::AlignCenter,QString::number(nod.getNumber()));
        }

        for(auto& nod: noduri)
        {
            for(auto& nod2: noduri)
            {
                if(nod.getNumber()!=nod2.getNumber())
                {
                    if(nod.getPoint().y()==nod2.getPoint().y()+40 && nod.getPoint().x()==nod2.getPoint().x())
                    {
                        g.AddArc(Arc(nod,nod2));
                        g.AddArc(Arc(nod2,nod));
                        p.setPen(QPen(Qt::black));
                        int x1 = nod.getPoint().x();
                        int y1 = nod.getPoint().y()-10;
                        int x2 = nod2.getPoint().x();
                        int y2 = nod2.getPoint().y()+10;
                        QPoint x(x1, y1);
                        QPoint y(x2, y2);
                        p.drawLine(QLine(x, y));
                    }
                    if(nod.getPoint().x()==nod2.getPoint().x()+40 && nod.getPoint().y()==nod2.getPoint().y())
                    {
                        g.AddArc(Arc(nod,nod2));
                        g.AddArc(Arc(nod2,nod));
                        p.setPen(QPen(Qt::black));
                        int x1 = nod.getPoint().x()-10;
                        int y1 = nod.getPoint().y();
                        int x2 = nod2.getPoint().x()+10;
                        int y2 = nod2.getPoint().y();
                        QPoint x(x1, y1);
                        QPoint y(x2, y2);
                        p.drawLine(QLine(x, y));
                    }
                }
            }
        }

    }

    if(button2==true)
    {
        if(button==true)
        {
            QPainter p(this);
            std::vector<Node> noduri = g.GetNoduri();
            for(auto& nod: noduri)
            {
                std::string col=nod.GetColor();
                if(col=="black")
                    p.setPen(QPen(Qt::black));
                if(col=="white")
                    p.setPen(QPen(Qt::black));
                if(col=="red")
                    p.setPen(QPen(Qt::red));
                if(col=="blue")
                    p.setPen(QPen(Qt::blue));
                if(col=="green")
                    p.setPen(QPen(Qt::green));
                QRect r(nod.getPoint().x()-10,nod.getPoint().y()-10, 20,20);
                p.drawEllipse(r);
                p.drawText(r,Qt ::AlignCenter,QString::number(nod.getNumber()));
            }

            for(auto& nod: noduri)
            {
                for(auto& nod2: noduri)
                {
                    if(nod.getNumber()!=nod2.getNumber())
                    {
                        if(nod.getPoint().y()==nod2.getPoint().y()+40 && nod.getPoint().x()==nod2.getPoint().x())
                        {
                            g.AddArc(Arc(nod,nod2));
                            g.AddArc(Arc(nod2,nod));
                            p.setPen(QPen(Qt::black));
                            int x1 = nod.getPoint().x();
                            int y1 = nod.getPoint().y()-10;
                            int x2 = nod2.getPoint().x();
                            int y2 = nod2.getPoint().y()+10;
                            QPoint x(x1, y1);
                            QPoint y(x2, y2);
                            p.drawLine(QLine(x, y));
                        }
                        if(nod.getPoint().x()==nod2.getPoint().x()+40 && nod.getPoint().y()==nod2.getPoint().y())
                        {
                            g.AddArc(Arc(nod,nod2));
                            g.AddArc(Arc(nod2,nod));
                            p.setPen(QPen(Qt::black));
                            int x1 = nod.getPoint().x()-10;
                            int y1 = nod.getPoint().y();
                            int x2 = nod2.getPoint().x()+10;
                            int y2 = nod2.getPoint().y();
                            QPoint x(x1, y1);
                            QPoint y(x2, y2);
                            p.drawLine(QLine(x, y));
                        }
                    }
                }
            }

        }
    }

    if(button3==true)
    {
        if(button==true)
        {
            QPainter p(this);
            int coordX,coordY;
            coordX=560;
            coordY=60;
            QVector<QVector<int>>mat;
            mat=g.GetMatrix();
            for(int i=0;i<mat.size();i++)
            {
                for(int j=0;j<mat[i].size();j++)
                {
                    p.setPen(QPen(Qt::black));
                    if(mat[i][j]==0)
                    {
                        p.setBrush(Qt::black);
                        p.drawRect(coordX,coordY,20,20);
                    }
                    if(mat[i][j]==1)
                    {
                        p.setBrush(Qt::white);
                        p.drawRect(coordX,coordY,20,20);
                    }
                    if(mat[i][j]==2)
                    {
                        p.setBrush(Qt::red);
                        p.drawRect(coordX,coordY,20,20);
                    }
                    if(mat[i][j]==3)
                    {
                        p.setBrush(Qt::blue);
                        p.drawRect(coordX,coordY,20,20);
                    }
                    coordX+=20;
                }
                coordY+=20;
                coordX=560;
            }

            //pt mat de drumuri - cu verde
            coordX=560;
            coordY=260;
            QVector<QVector<int>>matDrumuri;
            matDrumuri=g.GetMatrixDrumuri();

            for(int i=0;i<matDrumuri.size();i++)
            {
                for(int j=0;j<matDrumuri[i].size();j++)
                {
                    if(matDrumuri[i][j]==-1)
                    {
                        p.setBrush(Qt::black);
                        p.drawRect(coordX,coordY,20,20);
                    }
                    else
                    {
                        std::vector<Node> nodur=g.GetNoduri();
                        for(auto& nod:nodur)
                        {
                            if(matDrumuri[i][j]==nod.getNumber())
                            {
                                std::string color=nod.GetColor();
                                if(color=="black")
                                    p.setBrush(Qt::black);
                                if(color=="white")
                                    p.setBrush(Qt::white);
                                if(color=="red")
                                    p.setBrush(Qt::red);
                                if(color=="blue")
                                    p.setBrush(Qt::blue);
                                if(color=="green")
                                    p.setBrush(Qt::green);
                                p.drawRect(coordX,coordY,20,20);
                                break;
                            }
                        }
                    }
                    coordX+=20;
                }
                coordY+=20;
                coordX=560;
            }
        }
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_SaveGraf_released()
{

}

void MainWindow::on_pushButton_clicked()
{
    QFile file("C:/Users/ioana/Desktop/ioana/cursuri/Algoritmica grafurilor/Laborator/tema 3/problemaTema3/matrice.txt");
    file.open(QIODevice::ReadOnly | QIODevice::Text);
    QVector<QVector<int>>matrix;
    g.read(file,matrix);
    g.SetMatrix(matrix);
    /*for(int index=0;index<6;index++)
    {
        for(int index2=0;index2<6;index2++)
        {
            std::cout<<matrix[index][index2]<<" ";
        }
        std::cout<<std::endl;
    }*/
    //if(button==false)
    //{
        int coordX,coordY;
        coordX=60;
        coordY=60;
        for(int i=0;i<matrix.size();i++)
        {

            for(int j=0;j<matrix[i].size();j++)
            {
                if(matrix[i][j]!=0)
                {
                    QPoint p (coordX,coordY);
                    Node n(p);
                    if(matrix[i][j]==3)
                        n.SetColor("blue");
                    if(matrix[i][j]==2)
                        n.SetColor("red");
                    if(matrix[i][j]==1)
                        n.SetColor("white");
                    g.AddNod(n); //am setat nodul si culoarea lui; l-am pus in graf

                    if(matrix[i][j]==3)
                    {
                        Node aux;
                        aux=g.GetLastNode();
                        g.SetStart(aux);
                    }
                    if(matrix[i][j]==2)
                    {
                        Node aux;
                        aux=g.GetLastNode();
                        g.AddExitNode(aux);
                    }
                }
                coordX=coordX+40;
            }
            coordY=coordY+40;
            coordX=60;
        }
    //}
    button=true;
    update();
}

void MainWindow::on_pushButton_2_clicked()
{
    button2=true;
    g.PBF();
    update();
}

void MainWindow::on_pushButton_3_clicked()
{
    button3=true;
    g.createMatrixDrumuri();
    update();
}
